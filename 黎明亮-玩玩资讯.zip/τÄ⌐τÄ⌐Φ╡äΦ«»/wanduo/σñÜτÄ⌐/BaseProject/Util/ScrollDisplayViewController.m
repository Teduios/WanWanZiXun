//
//  ScrollDisplayViewController.m
//  BaseProject
//
//  Created by apple－jd08 on 15/10/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ScrollDisplayViewController.h"

@interface ScrollDisplayViewController ()<UIPageViewControllerDataSource,UIPageViewControllerDelegate>

@end

@implementation ScrollDisplayViewController

-(void)setCurrentPage:(NSInteger)currentPage{


    //  UIPageViewControllerNavigationDirectionForward,向右
//    UIPageViewControllerNavigationDirectionReverse向左
    NSInteger dirextion=0;
    if (_currentPage==currentPage) {
        return;
    }else if (_currentPage>currentPage){
        dirextion=1;
        
    
    }else {
        dirextion=0;
    }
    
    
    _currentPage=currentPage;
    
    
    UIViewController*vc=_controllers[currentPage];
    [_pageVC setViewControllers:@[vc] direction:dirextion animated:YES completion:nil];
    
}




//传入图片地址
-(instancetype)initWithImagePaths:(NSArray*)paths{
         NSMutableArray*arr=[NSMutableArray new];
    for(int i=0;i<paths.count   ;i++){
        id path=paths[i];
//        UIImageView*imageView=[UIImageView new];
        
        UIButton*btn=[UIButton buttonWithType:0];
        
        if ([self isURL:path]) {
            [btn sd_setBackgroundImageWithURL:path forState:0];
//            [imageView sd_setImageWithURL:path];
        }else if([self isNetPath:path]){
            NSURL*url=[NSURL URLWithString:path];
            [btn sd_setBackgroundImageWithURL:url forState:0];
//            [imageView sd_setImageWithURL:url];
        }else if([path isKindOfClass:[NSString class]]){
            NSURL*url=[NSURL fileURLWithPath:path];
            [btn sd_setBackgroundImageWithURL:url forState:0];
//            [imageView sd_setImageWithURL:url];
        }else {
            [btn setImage:[UIImage imageNamed:@"error@3x"] forState:0];
//            imageView.image=[UIImage imageNamed:@"error@3x"];
        
        }
        UIViewController*vc=[UIViewController new];
        vc.view=btn;
        btn.tag=1000+i;
        [btn bk_addEventHandler:^(UIButton* sender) {
            [self.delegate ScrollDisplayViewController:self didSelectedIndex:sender.tag-1000];
        } forControlEvents:UIControlEventTouchUpInside];
        [arr addObject:vc];
    }
    self=[self initWithViewControllers:arr];
    return self;
}

-(BOOL)isURL:(id)path{

    return [path isKindOfClass:[NSURL class]];

}

-(BOOL)isNetPath:(id)path{

    BOOL isStr=[path isKindOfClass:[NSString class]];
    if (!isStr) {
        return NO;
    }
    BOOL containHttp=[path rangeOfString:@"http"].location!=NSNotFound;
    BOOL containTile=[path rangeOfString:@"://"].location!=NSNotFound;
    return isStr&&containHttp   &&containTile;
}




//传入图片数组
-(instancetype)initWithImageNames:(NSArray*)names{
  
        NSMutableArray*arr=[NSMutableArray new];
        for(int i=0;i<names.count ;i++){
            UIImage*img=[UIImage imageNamed:names[i]];
//            UIImageView*iv=[[UIImageView alloc]initWithImage:img];
            UIButton*btn=[UIButton buttonWithType:0];
            [btn setBackgroundImage:img forState:0];
            
            UIViewController*vc=[UIViewController new];
            vc.view=btn;
            btn.tag=1000+i;
            [btn bk_addEventHandler:^(UIButton* sender) {
                [self.delegate ScrollDisplayViewController:self didSelectedIndex:sender.tag-1000];
            } forControlEvents:UIControlEventTouchUpInside];
            
            
            
            [arr addObject:vc];
            
        
        if (self=[self initWithViewControllers:arr]) {
            
        }
        
    }
    
    return self;
}

//传入试图控制器
-(instancetype)initWithViewControllers:(NSArray*)controllers{
    if (self=[super init]) {

        _controllers=[controllers copy];
        _autoCycle=YES;
        _canCycle=YES;
        _showPathControl=YES;
        _duration=3;
        _pageControlOffset=0;
        
        
    }
    
    return self;

}

-(void)setShowPageControl:(BOOL)showPageControl{

    _showPathControl=showPageControl;
    _pagecontrol.hidden=!showPageControl;

}

-(void)setDuration:(NSTimeInterval)duration{

    _duration=duration;
    self.autoCycle=_autoCycle;
    

}


-(void)setPageControlOffset:(CGFloat)pageControlOffset{
    _pageControlOffset=pageControlOffset;
    [_pagecontrol mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(_pageControlOffset);
    }];
}
-(void)setAutoCycle:(BOOL)autoCycle{

    _autoCycle=autoCycle;
    [_timer invalidate];
    if (!autoCycle) {
        return;
    }
    
    _timer=[NSTimer bk_scheduledTimerWithTimeInterval:_duration block:^(NSTimer *timer) {
        UIViewController*vc=_pageVC.viewControllers.firstObject;
        NSInteger index=[_controllers indexOfObject:vc];
        UIViewController*nextVC=nil;
        if (index==_controllers.count-1) {
            if (!_canCycle) {
                return ;
            }
            nextVC=_controllers.firstObject;
        }else{
        
            nextVC=_controllers[index+1];
    
        }
        __block ScrollDisplayViewController*vc1=self;
        [_pageVC setViewControllers:@[nextVC] direction:0 animated:YES completion:^(BOOL finished) {
            [vc1 configPageControl];
        }];
        
    } repeats:YES];


}

- (void)viewDidLoad {
    [super viewDidLoad];

    if (!_controllers||_controllers.count==0) {
        return;
    }
    
    
    _pageVC=[[UIPageViewController alloc]initWithTransitionStyle:1 navigationOrientation:0 options:nil];
    _pageVC.delegate=self;
    _pageVC.dataSource=self;
    [self addChildViewController:_pageVC];
    [self.view addSubview:_pageVC.view];
   [ _pageVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
       make.edges.mas_equalTo(self.view);
   }];
    
    [_pageVC setViewControllers:@[_controllers.firstObject ]direction:0 animated:YES completion:nil];
    _pagecontrol=[UIPageControl new];
    _pagecontrol.numberOfPages=_controllers.count;
    [self.view addSubview:_pagecontrol];
    [_pagecontrol mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.mas_equalTo(0);
        make.bottom.mas_equalTo(0);
    }];
    _pagecontrol.userInteractionEnabled=NO;

    self.autoCycle=_autoCycle;
    self.showPathControl=_showPathControl;
    self.pageControlOffset=_pageControlOffset;
}

-(void)configPageControl{

    NSInteger index=[self.controllers indexOfObject:_pageVC.viewControllers.firstObject];
    _pagecontrol.currentPage=index;

}
-(void)pageViewController:(UIPageViewController *)pageViewController didFinishAnimating:(BOOL)finished previousViewControllers:(NSArray<UIViewController *> *)previousViewControllers transitionCompleted:(BOOL)completed {
    if (completed&&finished) {
    [self configPageControl];
        NSInteger index=[_controllers indexOfObject:pageViewController.viewControllers.firstObject];
        if ([self.delegate respondsToSelector:@selector(ScrollDisplayViewController:currentIndex:)]) {
             [self.delegate ScrollDisplayViewController:self currentIndex:index];
        }
        
       
}
}

- (nullable UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController{
    NSInteger index=[_controllers indexOfObject:viewController ];
    if (index==0) {
        return self.controllers.lastObject;
    }
    return self.controllers[index-1];
}
- (nullable UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController{
    NSInteger index=[_controllers indexOfObject:viewController ];
    if (index==self.controllers.count-1) {
        return self.controllers.firstObject;
    }
    return self.controllers[index+1];
 
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
