//
//  ScrollDisplayViewController.h
//  BaseProject
//
//  Created by apple－jd08 on 15/10/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <UIButton+WebCache.h>
#import <UIImageView+WebCache.h>

@class ScrollDisplayViewController;
@protocol ScrollDisplayViewControllerDelegate <NSObject>

@optional

-(void)ScrollDisplayViewController:(ScrollDisplayViewController*)ScrollDisplayViewController didSelectedIndex:(NSInteger)index;

-(void)ScrollDisplayViewController:(ScrollDisplayViewController*)ScrollDisplayViewController currentIndex:(NSInteger)index;

@end

@interface ScrollDisplayViewController : UIViewController
{
    NSTimer*_timer;
    
}


@property(nonatomic,weak)id<ScrollDisplayViewControllerDelegate>delegate;




//传入图片地址
-(instancetype)initWithImagePaths:(NSArray*)paths;

//传入图片数组
-(instancetype)initWithImageNames:(NSArray*)names;

//传入试图控制器
-(instancetype)initWithViewControllers:(NSArray*)controllers;
@property(nonatomic,readonly)NSArray*paths;
@property(nonatomic,readonly)NSArray*names;
@property(nonatomic,readonly)NSArray*controllers;
@property(nonatomic,readonly)UIPageViewController*pageVC;
@property(nonatomic,readonly)UIPageControl*pagecontrol;

@property(nonatomic)BOOL canCycle;

@property(nonatomic)BOOL autoCycle;

@property(nonatomic)NSTimeInterval duration;

@property(nonatomic)BOOL showPathControl;

@property(nonatomic)NSInteger currentPage;

@property(nonatomic)CGFloat pageControlOffset;




@end
