//
//  HeroViewModel.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HeroViewModel.h"

@implementation HeroViewModel
-(NSInteger)rowNumber{

    return self.array.count;
}

-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
[BaiKeNetManager getMFHerocompletionHandle:^(FreeHeroModel* model, NSError *error) {
    if (!error) {
        self.array=model.free;
    }
    completionHandle(error);
}];

}



-(FreeHeroFreeModel*)modelForRow:(NSInteger)row{

    return self.array[row];
}

-(NSString*)cnNameForRow:(NSInteger)row{

    return [self modelForRow:row].cnName;
}
-(NSString*)titleForRow:(NSInteger)row{

    return [self modelForRow:row].title;
}
-(NSString*)locationForRow:(NSInteger)row{

    return [self modelForRow:row].location;
}
-(NSURL*)enNameForRow:(NSInteger)row{
return [NSURL URLWithString:[NSString stringWithFormat:@"http://img.lolbox.duowan.com/champions/%@_120x120.jpg",[self modelForRow:row].enName]];
}

-(NSString*)enNamesForRow:(NSInteger)row{
    
    
    return [self modelForRow:row].enName;
}



@end
