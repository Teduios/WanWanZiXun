//
//  fenlei2ViewModel.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/25.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "fenlei2ViewModel.h"

@implementation fenlei2ViewModel

-(NSInteger)rowNumber{
    return self.dataArr.count;
}
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
[ShiPinNetManager getcompletionHandle:^(id model, NSError *error) {
    self.dataArr=model;
    completionHandle(error);
}];

}
-(FenLeiModel*)modelForS:(NSInteger)row{
    return self.dataArr[row];

}
-(FenLeiSubModel*)modelWithS:(NSInteger)section ForRow:(NSInteger)row{

    return [self modelForS:section].subCategory[row];

}

-(NSString*)nameForS:(NSInteger)section ForRow:(NSInteger)row{
    return [self modelWithS:section  ForRow:row].name;

}
-(NSURL*)urlForS:(NSInteger)section ForRow:(NSInteger)row{

    return [NSURL URLWithString:[self modelWithS:section ForRow:row].icon];
}

-(NSString*)tagForS:(NSInteger)section ForRow:(NSInteger)row{
    return [self modelWithS:section  ForRow:row].tag;
}

@end
