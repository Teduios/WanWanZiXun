//
//  AllheroViewModel.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AllheroViewModel.h"

@implementation AllheroViewModel
-(NSInteger)rowNumber{
    
    return self.array.count;
}

-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    self.dataTask=[BaiKeNetManager getAllHerocompletionHandle:^(AllHeroModel *model, NSError *error) {
        if (!error) {
            self.array=model.all;
        }
        completionHandle(error);
    }];
    
}


-(AllHeroAllModel*)modelForRow:(NSInteger)row{

    return self.array[row];
}
-(NSString*)titleForRow:(NSInteger)row{
    return [self modelForRow:row].title;
}
-(NSURL*)enNameForRow:(NSInteger)row{
    return [NSURL URLWithString:[NSString stringWithFormat:@"http://img.lolbox.duowan.com/champions/%@_120x120.jpg",[self modelForRow:row].enName]];
}

-(NSString*)enNamesForRow:(NSInteger)row{


    return [self modelForRow:row].enName;
}




@end
