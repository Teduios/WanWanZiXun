//
//  FenleiViewModel.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "ShiPinNetManager.h"


@interface FenleiViewModel : BaseViewModel
-(NSURL*)iconForRow:(NSInteger)row;

-(NSString*)titleForRow:(NSInteger)row;

-(NSString*)upTimeForRow:(NSInteger)row;

-(NSString*)videoLengthForRow:(NSInteger)row;
-(NSString*)VidForRow:(NSInteger)row;
@property(nonatomic)NSInteger page;
@property(nonatomic)NSInteger rowNumber;
@property(nonatomic,strong)NSString*tag;


-(instancetype)initWithTAg:(NSString*)tag;

@end
