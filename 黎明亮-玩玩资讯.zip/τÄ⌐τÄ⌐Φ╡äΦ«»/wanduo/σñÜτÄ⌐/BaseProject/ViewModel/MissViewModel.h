//
//  MissViewModel.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "ShiPinNetManager.h"
@interface MissViewModel : BaseViewModel
@property(nonatomic)NSInteger rowNumber;

-(NSURL*)iconForRow:(NSInteger)row;

-(NSString*)titleForRow:(NSInteger)row;

-(NSString*)upTimeForRow:(NSInteger)row;

-(NSString*)videoLengthForRow:(NSInteger)row;
-(NSString*)VidForRow:(NSInteger)row;
@property(nonatomic)NSInteger page;

-(id)initWithName:(NSString*)name;
@property(nonatomic,strong)NSString*name;

@end
