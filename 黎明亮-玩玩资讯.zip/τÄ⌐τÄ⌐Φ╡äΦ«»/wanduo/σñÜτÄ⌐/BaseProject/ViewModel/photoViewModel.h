//
//  photoViewModel.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/4.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "AlbumNetManager.h"
@interface photoViewModel : BaseViewModel

-(id)initWithDuoWanType:(AlbumType)type;
@property(nonatomic)AlbumType type;

@property(nonatomic) NSInteger page;
- (NSURL *)iconForRow:(NSInteger)row;
@property(nonatomic) NSInteger rowNumber;
-(NSString*)galleryIdForRow:(NSInteger)row;
@end
