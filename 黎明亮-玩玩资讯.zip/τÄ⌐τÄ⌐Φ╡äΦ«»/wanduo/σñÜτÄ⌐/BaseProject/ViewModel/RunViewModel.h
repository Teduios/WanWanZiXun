//
//  RunViewModel.h
//  BaseProject
//
//  Created by apple－jd08 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "BaiKeNetManager.h"
@interface RunViewModel : BaseViewModel
@property(nonatomic)NSInteger rowNumber;
-(NSArray*)iplevForRow:(NSInteger)row;
-(NSArray*)levForRow:(NSInteger)row;
-(NSString*)nameForRow:(NSInteger)row;
-(NSString*)propForRow:(NSInteger)row;

@end
