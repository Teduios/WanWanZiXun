//
//  HeroDetailViewModel.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HeroDetailViewModel.h"

@implementation HeroDetailViewModel


-(NSDictionary*)dic{
    if (!_dic) {
        _dic=[NSDictionary dictionary];
        
    }
    return _dic;
}


-(id)initWithHeroName:(NSString *)HeroName{
    if (self=[super init]) {
        self.HeroName=HeroName;
    }
    return self;
}

-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
self.dataTask=[BaiKeNetManager getHeroDetailWithHeroName:_HeroName completionHandle:^(HeroDetailModel* model, NSError *error) {

        _dic=model;
  
    
    
    completionHandle(error);
}];

}

- (HeroDetailModel*)modelForRow{
    return  _dic;

}

-(NSString*)descForRow{

    return [self modelForRow].desc;
}

-(NSString*)tagsForRow{
    return [self modelForRow].tags;
}

-(NSString*)displayNameForRow{

    return [self modelForRow].displayName;
}


-(NSString*)opponenTipsForRow{
    return [self modelForRow].opponentTips;
}

-(NSString*)tipForRow{

    return  [self modelForRow].tips;
}






@end
