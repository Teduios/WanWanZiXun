//
//  duowanViewModel.h
//  BaseProject
//
//  Created by apple－jd08 on 15/10/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "duowanNetManager.h"
@interface duowanViewModel : BaseViewModel

-(id)initWithDuoWanType:(DuoWanType)type;
@property(nonatomic)DuoWanType type;


@property(nonatomic)NSInteger rowNumber;
@property(nonatomic)NSInteger page;
- (NSURL *)iconURLForRow:(NSInteger)row;
- (NSString *)titleForRow:(NSInteger)row;
- (NSString *)contentForRow:(NSInteger)row;
-(NSString*)readCountForRow:(NSInteger)row;
-(NSString*)timeForRow:(NSInteger)row;
-(NSNumber*)adIDForRow:(NSInteger)row;

-(NSNumber*)IDForRow:(NSInteger)row;

@property(nonatomic,strong) NSArray *headImageURLs;



@end
