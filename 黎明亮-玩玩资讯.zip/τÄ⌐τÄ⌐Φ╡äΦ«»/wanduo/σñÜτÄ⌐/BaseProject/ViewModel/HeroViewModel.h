//
//  HeroViewModel.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "BaiKeNetManager.h"
@interface HeroViewModel : BaseViewModel
-(NSString*)cnNameForRow:(NSInteger)row;
-(NSString*)titleForRow:(NSInteger)row;
-(NSString*)locationForRow:(NSInteger)row;
-(NSURL*)enNameForRow:(NSInteger)row;
-(NSString*)enNamesForRow:(NSInteger)row;
-(FreeHeroFreeModel*)modelForRow:(NSInteger)row;


@property(nonatomic)NSInteger rowNumber;

@end
