//
//  duowanViewModel.m
//  BaseProject
//
//  Created by apple－jd08 on 15/10/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "duowanViewModel.h"

@implementation duowanViewModel

-(NSNumber*)adIDForRow:(NSInteger)row{

    duowanheaderLine*model=self.headImageURLs[row];
    return model.ID;
}

-(NSInteger)rowNumber{
    return self.dataArr.count;

}

-(id)initWithDuoWanType:(DuoWanType)type{
    if (self=[super init]) {
        _type=type;
    }
    return self;
}


-(duowandata*)DWdataForRow:(NSInteger)row{

    return self.dataArr[row];
}



-(NSURL*)iconURLForRow:(NSInteger)row{

    return [NSURL URLWithString:[self DWdataForRow:row].srcPhoto];

}

-(NSString*)titleForRow:(NSInteger)row{

    return [self DWdataForRow:row].title;
}

-(NSString*)contentForRow:(NSInteger)row{

    return [self DWdataForRow:row].content;
    
}
-(NSString*)readCountForRow:(NSInteger)row{

    return [[self DWdataForRow:row].readCount stringByAppendingString:@"阅读"];
}


-(NSNumber*)IDForRow:(NSInteger)row{

    return [self DWdataForRow:row].ID ;

}

-(NSString*)timeForRow:(NSInteger)row{

    //获取当前秒数

    NSInteger currentTime= [[NSDate date] timeIntervalSince1970];
//算出当前时间和创建时间的间隔秒数
    NSTimeInterval delta = currentTime-[self DWdataForRow:row].time;
    //秒数转小时
    NSInteger hours = delta/3600;
    NSInteger  fen=delta/60;
    if (fen<60) {
        return [NSString stringWithFormat:@"%ld分钟前",fen];
    }
    NSString*time=[NSString stringWithFormat:@"%lld",[self DWdataForRow:row].time];
    long long int date1 = (long long int)[time intValue];
    NSDate *date2 = [NSDate dateWithTimeIntervalSince1970:date1];
    NSDateFormatter*formatter=[NSDateFormatter new];
    formatter.dateFormat=@" hh:mm";
    NSString *formatString = [formatter stringFromDate:date2];
    
    if (hours < 24) {
        return [NSString stringWithFormat:@"%@",formatString];
    }
    //秒数转天数
    NSInteger days = delta/3600/24;
    return [NSString stringWithFormat:@"%ld天前", days];
   



}




-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{

    [duowanNetManager GetDuoWanType:_type Page:_page completionHandle:^(duowan *model, NSError *error) {
        if (_page==1) {
            [self.dataArr removeAllObjects];
        }
    [self.dataArr addObjectsFromArray:model.data];
        self.headImageURLs =[model.headerline copy];
    completionHandle(error);
    
}];

}
-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    _page=1;
    
    [self getDataFromNetCompleteHandle:completionHandle];
}
-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    _page+=1;
    [self getDataFromNetCompleteHandle:completionHandle];
    

}





@end
