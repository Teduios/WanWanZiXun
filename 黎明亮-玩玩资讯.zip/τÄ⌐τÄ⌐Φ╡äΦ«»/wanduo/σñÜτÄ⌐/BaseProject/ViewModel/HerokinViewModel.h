//
//  HerokinViewModel.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "BaiKeNetManager.h"
@interface HerokinViewModel : BaseViewModel

-(NSString*)smallimgForRow:(NSInteger)row;
-(NSNumber*)IDForRow:(NSInteger)row;
- (id)initWithTag:(NSString *)enName;
@property(nonatomic,strong) NSString *enName;

@property(nonatomic)NSInteger rowNumber;

@end
