//
//  PicViewModel.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicViewModel.h"

@implementation PicViewModel
-(id)initWithgalleryId:(NSString *)galleryId{
    if (self=[super init]) {
        self.galleryId=galleryId;
    }
    return self;
}
-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
self.dataTask=[PivNetModel getGalleryId:_galleryId completionHandle:^(PicModel *model, NSError *error) {
    [self.dataArr addObjectsFromArray:model.pictures];
    completionHandle(error);
}];

}
-(PicPicturesModel*)modelForRor:(NSInteger)row{

    return self.dataArr[row];

}

- (NSInteger)rowNumber{
    return self.dataArr.count;
}
- (NSURL *)picURLForRow:(NSInteger)row{
    return [NSURL URLWithString:[self modelForRor:row].url];
}
-(NSString*)picDescForRow:(NSInteger)row{
    return [self modelForRor:row].picDesc;

}



@end
