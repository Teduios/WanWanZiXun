//
//  ShiPinViewModel.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ShiPinViewModel.h"

@implementation ShiPinViewModel


-(NSInteger)rowNumber{
    return self.dataArr.count;
}

-(id)initWithShiPinType:(ShiPinType)type{
    if (self=[super init]) {
        _type=type;
    }
    return self;
}
-(newestModel*)newestForRow:(NSInteger)row{
    
    return self.dataArr[row];
}

-(NSURL*)iconForRow:(NSInteger)row{
    
    return [NSURL URLWithString:[self newestForRow:row].coverUrl];
}

-(NSString*)titleForRow:(NSInteger)row{
    
    return [self newestForRow:row].title;
    
}
-(NSString*)VidForRow:(NSInteger)row{
    return [self newestForRow:row].vid;
}

-(NSString*)upTimeForRow:(NSInteger)row{
    return [self newestForRow:row].uploadTime;
}
-(NSString*)videoLengthForRow:(NSInteger)row{
    NSInteger time=[self newestForRow:row].videoLength;
    NSInteger fen=time/60;
    NSInteger miao=time%60;
    return [NSString stringWithFormat:@"%ld.%ld",fen,miao];
}

-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    
    [ShiPinNetManager GetShiPinType:_type Page:_page  completionHandle:^(id model, NSError *error) {
        if (_page==1) {
            [self.dataArr removeAllObjects];
        }
    
             [self.dataArr addObjectsFromArray:model];
        completionHandle(error);
        
    }];
    
    
}



-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    _page=1;
    
    [self getDataFromNetCompleteHandle:completionHandle];
}
-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    _page+=1;
    [self getDataFromNetCompleteHandle:completionHandle];
    
    
}




@end
