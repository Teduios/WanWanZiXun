//
//  ShiPinViewModel.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "ShiPinNetManager.h"
@interface ShiPinViewModel : BaseViewModel

@property(nonatomic)NSInteger rowNumber;

-(NSURL*)iconForRow:(NSInteger)row;

-(NSString*)titleForRow:(NSInteger)row;

-(NSString*)upTimeForRow:(NSInteger)row;

-(NSString*)videoLengthForRow:(NSInteger)row;
-(NSString*)VidForRow:(NSInteger)row;




-(id)initWithShiPinType:(ShiPinType)type;
@property(nonatomic)ShiPinType type;
@property(nonatomic)NSInteger page;

@end
