//
//  photoViewModel.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/4.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "photoViewModel.h"

@implementation photoViewModel

-(id)initWithDuoWanType:(AlbumType)type{
    if (self=[super init]) {
        _type=type;
    }
    return self;
}
-(AlbumDataModel*)modelForRow:(NSInteger)row{
    
    return self.dataArr[row];
}

- (NSURL *)iconForRow:(NSInteger)row{
    AlbumDataModel *data = self.dataArr[row];
    return [NSURL URLWithString:data.coverUrl];
}

-(NSString*)galleryIdForRow:(NSInteger)row{
    
    
    return [self modelForRow:row].galleryId;
}

- (NSInteger)rowNumber{
    return self.dataArr.count;
}
-(void)refreshDataCompletionHandle:(CompletionHandle)completionHandle{
    _page = 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}
-(void)getMoreDataCompletionHandle:(CompletionHandle)completionHandle{
    _page += 1;
    [self getDataFromNetCompleteHandle:completionHandle];
}



-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
    [AlbumNetManager getBeautifulWomanForPage:_page Type:_type completionHandle:^(AlbumModel *model, NSError *error) {
        if (_page == 1) {
            [self.dataArr removeAllObjects];
        }
        [self.dataArr addObjectsFromArray:model.data];
        completionHandle(error);
    }];
    
}
@end
