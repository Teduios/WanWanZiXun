//
//  HeroDetailViewModel.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "BaiKeNetManager.h"
@interface HeroDetailViewModel : BaseViewModel
-(id)initWithHeroName:(NSString*)HeroName;
@property(nonatomic,strong)NSString*HeroName;

@property(nonatomic,strong)NSMutableArray*likeArr;
@property(nonatomic,strong)NSMutableArray*hateArr;
@property(nonatomic,strong)NSDictionary*dic;

-(NSString*)tipForRow;

-(NSString*)displayNameForRow;

-(NSString*)opponenTipsForRow;

-(NSString*)tagsForRow;



-(NSString*)descForRow;

- (HeroDetailModel*)modelForRow;
@end
