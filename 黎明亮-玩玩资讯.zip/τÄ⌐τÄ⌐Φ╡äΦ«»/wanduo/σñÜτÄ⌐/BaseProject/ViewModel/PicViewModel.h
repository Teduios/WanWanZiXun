//
//  PicViewModel.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "PivNetModel.h"
@interface PicViewModel : BaseViewModel
-(id)initWithgalleryId:(NSString*)galleryId;
@property(nonatomic,strong)NSString*galleryId;
-(NSURL*)picURLForRow:(NSInteger)row;
@property(nonatomic) NSInteger rowNumber;
-(NSString*)picDescForRow:(NSInteger)row;
@end
