//
//  AllheroViewModel.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "BaiKeNetManager.h"
@interface AllheroViewModel : BaseViewModel
-(NSString*)titleForRow:(NSInteger)row;
-(NSURL*)enNameForRow:(NSInteger)row;
-(NSString*)enNamesForRow:(NSInteger)row;
-(NSString*)priceForRow:(NSInteger)row;
-(NSString*)ratingForRow:(NSInteger)row;
@property(nonatomic)NSInteger rowNumber;
-(AllHeroAllModel*)modelForRow:(NSInteger)row;
@end
