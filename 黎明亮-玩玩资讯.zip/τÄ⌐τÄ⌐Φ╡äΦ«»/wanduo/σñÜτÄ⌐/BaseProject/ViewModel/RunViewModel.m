//
//  RunViewModel.m
//  BaseProject
//
//  Created by apple－jd08 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RunViewModel.h"

@implementation RunViewModel
-(NSInteger)rowNumber{
    return self.dataArr.count;
}

-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
[BaiKeNetManager getRunesCompletionHandle:^(RuneModel* model, NSError *error) {
//    [self.dataArr addObjectsFromArray:model.purple];
    self.dataArr=model.purple;
    completionHandle(error);
}];

}


-(RunePurpleModel*)modelForRow:(NSInteger)row{
    return self.dataArr[row];
}
//-(NSArray*)iplevForSection:(NSInteger)section ForRow:(NSInteger)row{
//return @[[self modelForSection:section ForRow:row].iplev1,
//         [self modelForSection:section ForRow:row].iplev2,
//         [self modelForSection:section ForRow:row].iplev3];
//}
//
//-(NSArray*)levForSection:(NSInteger)section ForRow:(NSInteger)row{
//    return @[[self modelForSection:section ForRow:row].lev1,
//             [self modelForSection:section ForRow:row].lev2,
//             [self modelForSection:section ForRow:row].lev3];
//}
//-(NSString*)nameForSection:(NSInteger)section ForRow:(NSInteger)row{
//    return [self modelForSection:section ForRow:row].name;
//}
//-(NSString*)propForSection:(NSInteger)section ForRow:(NSInteger)row{
//    return [self modelForSection:section ForRow:row].prop;
//}

-(NSArray*)iplevForRow:(NSInteger)row{
return @[[self modelForRow:row].iplev1,
        [self modelForRow:row].iplev2,
         [self modelForRow:row].iplev3];

}
-(NSArray*)levForRow:(NSInteger)row{

return @[[self modelForRow:row].lev1,
         [self modelForRow:row].lev2,
         [self modelForRow:row].lev3];
}
-(NSString*)nameForRow:(NSInteger)row{
    return [self modelForRow:row].name;

}
-(NSString*)propForRow:(NSInteger)row{

    return [self modelForRow:row].prop;
}

@end
