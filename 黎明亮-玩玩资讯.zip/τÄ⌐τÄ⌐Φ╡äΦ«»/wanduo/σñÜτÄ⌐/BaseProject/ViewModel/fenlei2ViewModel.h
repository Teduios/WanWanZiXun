//
//  fenlei2ViewModel.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/25.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseViewModel.h"
#import "FenleiViewModel.h"
@interface fenlei2ViewModel : BaseViewModel

@property(nonatomic)NSInteger rowNumber;
-(NSURL*)urlForS:(NSInteger) section ForRow:(NSInteger)row;
-(NSString*)nameForS:(NSInteger) section ForRow:(NSInteger)row;
-(NSString*)tagForS:(NSInteger) section ForRow:(NSInteger)row;

@end
