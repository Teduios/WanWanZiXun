//
//  HerokinViewModel.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HerokinViewModel.h"

@implementation HerokinViewModel

-(NSInteger)rowNumber{
    return self.dataArr.count;
}


-(id)initWithTag:(NSString *)enName{
    if (self=[super init]) {
        self.enName=enName;
    }
    return self;
}


-(void)getDataFromNetCompleteHandle:(CompletionHandle)completionHandle{
 [BaiKeNetManager getHeroSkinsWithHeroName:_enName completionHandle:^(id model, NSError *error) {
     if (!error) {
          self.dataArr=model;
     }
     completionHandle(error);
 }];
}

-(HeroSkinModel*)modelForRow:(NSInteger)row{

    return self.dataArr[row];
}
-(NSString*)smallimgForRow:(NSInteger)row{

    return [self modelForRow:row].smallImg;
}
-(NSNumber*)IDForRow:(NSInteger)row{

    return [self modelForRow:row].ID;

}

@end
