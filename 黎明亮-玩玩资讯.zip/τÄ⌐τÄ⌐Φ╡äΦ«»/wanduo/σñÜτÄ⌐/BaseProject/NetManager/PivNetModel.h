//
//  PivNetModel.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "PicModel.h"
@interface PivNetModel : BaseNetManager
+(id)getGalleryId:(NSString*)galleryId completionHandle:(void(^)(PicModel *model, NSError *error))complete;
@end
