//
//  ShiPinNetManager.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "newestModel.h"
#import "BoFangModel.h"
#import "FenLeiModel.h"
#import "MissModel.h"
typedef NS_ENUM(NSUInteger, ShiPinType){
    ShiPinTypeNewest,
    ShiPinTypeTopN,
    
};
@interface ShiPinNetManager : BaseNetManager

+(id)GetShiPinType:(ShiPinType)type  Page:(NSInteger)page completionHandle:(void(^)(id model,NSError*error))complete;

+(id)getVID:(NSString*)VID completionHandle:(void(^)(BoFangModel* model,NSError*error))complete;

+(id)getcompletionHandle:(void(^)(id model,NSError*error))complete;


+(id)getXAJSName:(NSString*)name Page:(NSInteger)page completionHandle:(void(^)(id model,NSError*error))complete;


+(id)getAllPage:(NSInteger)page Tag:(NSString*)tag completionHandle:(void(^)(id model,NSError*error))complete;

@end
