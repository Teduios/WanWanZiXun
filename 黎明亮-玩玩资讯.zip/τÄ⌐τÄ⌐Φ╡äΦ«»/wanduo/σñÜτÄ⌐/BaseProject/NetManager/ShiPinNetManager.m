//
//  ShiPinNetManager.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ShiPinNetManager.h"

@implementation ShiPinNetManager

+(id)GetShiPinType:(ShiPinType)type Page:(NSInteger)page completionHandle:(void(^)(id model,NSError*error))complete{
    NSString*path=nil;
    switch (type) {
        case ShiPinTypeTopN:
            path=[NSString stringWithFormat:@"http://box.dwstatic.com/apiVideoesNormalDuowan.php?src=duowan&action=l&sk=&pageUrl=&heroEnName=&tag=topN&p=%@",@(page)];
            break;
        case ShiPinTypeNewest:
            path=[NSString stringWithFormat:@"http://box.dwstatic.com/apiVideoesNormalDuowan.php?src=duowan&action=l&sk=&pageUrl=&heroEnName=&tag=newest&p=%@",@(page)];
            break;
        default:
            break;
    }

    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        complete([newestModel objectArrayWithKeyValuesArray:responseObj],error);

    }];
    
}
+(id)getVID:(NSString*)VID completionHandle:(void(^)(BoFangModel* model,NSError*error))complete{
    
    NSString*path=[NSString stringWithFormat:@"http://box.dwstatic.com/apiVideoesNormalDuowan.php?action=f&cf=android&check_code=null&format=json&payer_name=null&plat=android2.2&uu=&ver=2.0&vid=%@&vu=null&sign=signxxxxx",VID];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        
        complete([BoFangModel objectWithKeyValues:responseObj],error);
    }];
    
}

+(id)getcompletionHandle:(void (^)(id, NSError *))complete{
    
    NSString*path=@"http://box.dwstatic.com/apiVideoesNormalDuowan.php?src=duowan&action=c&sk=&sn=%E7%94%B5%E4%BF%A1%E5%8D%81%E4%BA%94&pn=%E7%99%BD%E5%A4%A9%E8%93%9D%E4%BA%91";
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        
     
        complete([FenLeiModel objectArrayWithKeyValuesArray:responseObj],error);
    }];
    
}

+(id)getXAJSName:(NSString *)name Page:(NSInteger)page completionHandle:(void (^)(id, NSError *))complete{
    NSString*path=[NSString stringWithFormat:@"http://box.dwstatic.com/apiVideoesNormalDuowan.php?src=duowan&action=l&sk=&pageUrl=&heroEnName=&tag=%@&p=%@",name,@(page)];
    
    
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        complete([MissModel objectArrayWithKeyValuesArray:responseObj],error);
    }];


}

+(id)getAllPage:(NSInteger)page Tag:(NSString *)tag completionHandle:(void (^)(id, NSError *))complete{

    NSString*path=[NSString stringWithFormat:@"http://box.dwstatic.com/apiVideoesNormalDuowan.php?src=duowan&action=l&sk=&pageUrl=&heroEnName=&tag=%@&p=%@",tag,@(page)];

    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        complete([MissModel objectArrayWithKeyValuesArray:responseObj],error);
    }];
    
}


@end
