//
//  duowanNetManager.m
//  BaseProject
//
//  Created by apple－jd08 on 15/10/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "duowanNetManager.h"

@implementation duowanNetManager

+(id)GetDuoWanType:(DuoWanType)type Page:(NSInteger)page  completionHandle:(void (^)(duowan *, NSError *))complete{

    NSString*path=nil;
    switch (type) {
        case DuoWanTypeTouTaio:
            path=[NSString stringWithFormat:@"http://box.dwstatic.com/apiNewsList.php?action=l&newsTag=headlineNews&p=%@",@(page)];
            break;
            case DuoWanTypeShiPing:
            path=[NSString stringWithFormat:@"http://box.dwstatic.com/apiNewsList.php?action=l&newsTag=newsVideo&p=%@",@(page)];
            break;
        case DuoWanTypeSaiShi:
            path=[NSString stringWithFormat:@"http://box.dwstatic.com/apiNewsList.php?action=l&newsTag=upgradenews&p=%@",@(page)];
            break;
        
        default:
            break;
    }

return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
    complete([duowan objectWithKeyValues:responseObj],error);
}];

}


@end
