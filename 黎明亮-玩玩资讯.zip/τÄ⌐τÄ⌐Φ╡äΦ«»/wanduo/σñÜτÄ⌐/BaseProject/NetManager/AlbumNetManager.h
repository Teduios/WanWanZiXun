//
//  AlbumNetManager.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/4.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "AlbumModel.h"

typedef NS_ENUM(NSUInteger, AlbumType){
    AlbumTypeWoman,
    AlbumTypeJiongTu,
    AlbumTypeBiZi,
    
    
};

@interface AlbumNetManager : BaseNetManager
+ (id)getBeautifulWomanForPage:(NSInteger)page Type:(AlbumType)type completionHandle:(void(^)(AlbumModel *model, NSError *error))complete;

@end