//
//  AlbumNetManager.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/4.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AlbumNetManager.h"



@implementation AlbumNetManager
+ (id)getBeautifulWomanForPage:(NSInteger)page Type:(AlbumType)type completionHandle:(void(^)(AlbumModel *model, NSError *error))complete{
    NSString*path=nil;
    switch (type) {
            case AlbumTypeWoman:
            path=[NSString stringWithFormat:@"http://box.dwstatic.com/apiAlbum.php?action=l&albumsTag=beautifulWoman&p=%@",@(page)];
            break;
        case AlbumTypeJiongTu:
               path=[NSString stringWithFormat:@"http://box.dwstatic.com/apiAlbum.php?action=l&albumsTag=jiongTu&p=%@",@(page)];
            break;
        case AlbumTypeBiZi:
            path=[NSString stringWithFormat:@"http://box.dwstatic.com/apiAlbum.php?action=l&albumsTag=wallpaper&p=%@",@(page)];
            break;
        default:
            break;
    }
//    NSDictionary *params=@{@"v":@"77", @"OSType":@"iOS8.2", @"versionName":@"2.1.7"};
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        complete([AlbumModel objectWithKeyValues:responseObj],error);
    }];
    
    
}




@end
