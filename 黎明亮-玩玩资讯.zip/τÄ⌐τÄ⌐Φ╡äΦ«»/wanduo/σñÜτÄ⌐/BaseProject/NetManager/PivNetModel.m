
//
//  PivNetModel.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PivNetModel.h"

@implementation PivNetModel
+(id)getGalleryId:(NSString*)galleryId completionHandle:(void(^)(PicModel *model, NSError *error))complete{

    NSString*path=[NSString stringWithFormat:@"http://box.dwstatic.com/apiAlbum.php?action=d&albumId=%@",galleryId];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        complete([PicModel objectWithKeyValues:responseObj],error);
    }];

}
@end
