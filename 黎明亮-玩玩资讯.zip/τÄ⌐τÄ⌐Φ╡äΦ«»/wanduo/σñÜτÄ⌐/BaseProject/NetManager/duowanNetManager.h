//
//  duowanNetManager.h
//  BaseProject
//
//  Created by apple－jd08 on 15/10/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseNetManager.h"
#import "duowan.h"

typedef NS_ENUM(NSUInteger, DuoWanType){
    DuoWanTypeTouTaio,
    DuoWanTypeShiPing,
    DuoWanTypeSaiShi,



};

@interface duowanNetManager : BaseNetManager

+(id)GetDuoWanType:(DuoWanType)type  Page:(NSInteger)page completionHandle:(void(^)(duowan*model,NSError*error))complete;


@end
