//
//  GiftModel.m
//  BaseProject
//
//  Created by jiyingxin on 15/11/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "GiftModel.h"

@implementation GiftModel


+ (NSDictionary *)objectClassInArray{
    return @{@"a" : [GiftAModel class], @"d" : [GiftAModel class], @"g" : [GiftAModel class]};
}
@end
@implementation GiftAModel

@end


