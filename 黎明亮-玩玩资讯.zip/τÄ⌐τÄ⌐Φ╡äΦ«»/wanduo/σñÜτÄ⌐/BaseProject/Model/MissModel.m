
//
//  MissModel.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MissModel.h"

@implementation MissModel
+(NSDictionary*)replacedKeyFromPropertyName{

    return @{@"coverUrl":@"cover_url",@"uploadTime":@"upload_time",@"videoLength":@"video_length",@"letvvideounique":@"letv_video_unique",@"letvvideoid":@"letv_video_id"};
}

@end


