//
//  FenLeiModel.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@interface FenLeiModel : BaseModel
@property (nonatomic, strong) NSString *group;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSArray *subCategory;
@end

@interface FenLeiSubModel : BaseModel
@property (nonatomic, strong) NSString *icon;
@property (nonatomic, strong) NSString *uid;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *tag;
@property (nonatomic, strong) NSString *dailyUpdate;
@end