//
//  GameListModel.m
//  Day07_GameLive
//
//  Created by jiyingxin on 15/10/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "GameListModel.h"

@implementation GameListModel
+ (id)parse:(NSDictionary *)responseObj{
    GameListModel *model=[super parse:responseObj];
    NSMutableArray *arr=[NSMutableArray new];
    for (NSDictionary *dic in responseObj[@"data"]) {
        [arr addObject:[GameListDataModel parse:dic]];
    }
    model.data = [arr copy];
    return model;
}
/*
- (id)init{
    if (self = [super init]) {
        _data = [NSMutableArray new];
    }
    return self;
}
*/
@end

@implementation GameListDataModel
/*
+ (id)parse:(NSDictionary *)responseObj{
    GameListDataModel *model=[GameListDataModel new];
    //    model.cate_id =responseObj[@"cate_id"];
    //使用KVC模式进行赋值
    //使用KVC会有一个问题，对不存在key赋值会crash，为了预防这个错误的发生，我们要重写它的setValue:forUndefinedKey方法
    for (NSString *key in responseObj.allKeys) {
        [model setValue:responseObj[key] forKey:key];
    }
    return model;
}
 */
//如果创建了100个类，就要重写100次下方的方法，需要让所有的Model类型继承同一个基类，来解决这个问题---程序设计
//- (void)setValue:(id)value forUndefinedKey:(NSString *)key{
//    
//}

@end













