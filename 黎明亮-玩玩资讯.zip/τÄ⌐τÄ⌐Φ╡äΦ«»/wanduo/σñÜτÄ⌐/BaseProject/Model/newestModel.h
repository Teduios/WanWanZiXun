//
//  newestModel.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"



@interface newestModel : BaseModel
@property (nonatomic, strong) NSString *coverUrl;
@property (nonatomic, strong) NSString *udb;
@property (nonatomic, strong) NSString *channelId;
@property (nonatomic, strong) NSString *uploadTime;
@property (nonatomic, strong) NSString *vid;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *letvVideoUnique;
@property (nonatomic, strong) NSString *letvVideoId;
@property (nonatomic, assign) double videoLength;
@property (nonatomic, assign) double totalPage;
@property (nonatomic, strong) NSString *editorId;
@property (nonatomic, strong) NSString *introduction;
@property (nonatomic, strong) NSString *videoId;
@property (nonatomic, strong) NSString *amountPlay;
@property (nonatomic, strong) NSString *isRecommd;
@property (nonatomic, strong) NSString *notes;
@property (nonatomic, strong) NSString *topLeftFlag;



/*"amount_play": "163W次+",
 "channelId": "lolboxvideo",
 "cover_url": "http://vimg.dwstatic.com/1544/178989/4-220x124.jpg",
 "editorId": "",
 "introduction": "",
 "is_recommd": "0",
 "letv_video_id": "",
 "letv_video_unique": "178989",
 "notes": "",
 "title": "徐老师来巡山37：智商感人集体抱团撞大墙",
 "top_left_flag": "1",
 "udb": "",
 "upload_time": "2015-10-26 18:54:01",
 "vid": "178989",
 "video_id": "",
 "video_length": "802"*/

/*"channelId": "lolboxvideo",
 "cover_url": "http://vimg.dwstatic.com/1545/184176/4-220x124.jpg",
 "letv_video_id": "0",
 "letv_video_unique": "",
 "title": "奇趣集锦：别惹我，我的忍耐力是有限的",
 "totalPage": 2281,
 "udb": "dw_zhengzhibin1",
 "upload_time": "2015-11-06 14:35:24",
 "vid": "184328",
 "video_length": 206*/

@end

