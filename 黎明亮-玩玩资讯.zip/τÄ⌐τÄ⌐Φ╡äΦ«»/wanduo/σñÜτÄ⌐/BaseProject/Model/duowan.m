//
//  duowan.m
//  BaseProject
//
//  Created by apple－jd08 on 15/10/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "duowan.h"

@implementation duowan

+(NSDictionary*)objectClassInArray{

    return @{@"data":[duowandata class],@"headerline":[duowanheaderLine class]};

}


@end

@implementation duowandata
+(NSDictionary*)replacedKeyFromPropertyName{

    return @{@"ID":@"id"};
}


@end
@implementation duowanheaderLine

+(NSDictionary*)replacedKeyFromPropertyName{
    
    return @{@"ID":@"id"};
}


@end