//
//  BoFangModel.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"
@class BoFangResultModel,BoFangResultItemsModel,BoFangResultItemsThreeModel,BoFangResultItemsYiQianModel,BoFangResultItemsYiQianSanModel,BoFangResultItemsThreeTranscodeModel;
@interface BoFangModel : BaseModel
@property (nonatomic, strong) NSString *message;
@property (nonatomic, strong) BoFangResultModel *result;
@property (nonatomic, assign) double code;
@end

@interface BoFangResultModel : BaseModel
@property (nonatomic, strong) BoFangResultItemsModel *items;
@property (nonatomic, strong) NSString *cover;
@end
@interface BoFangResultItemsModel : BaseModel
@property (nonatomic, strong) BoFangResultItemsThreeModel *Three;
@property (nonatomic, strong) BoFangResultItemsYiQianModel*YiQian;
@property (nonatomic, strong) BoFangResultItemsYiQianSanModel *YiQianSan;
@end
@interface BoFangResultItemsThreeModel : BaseModel
@property (nonatomic, strong) BoFangResultItemsThreeTranscodeModel *transcode;
@property (nonatomic, strong) NSString *videoName;
@property (nonatomic, strong) NSString *transcodeId;
@property (nonatomic, strong) NSString *vid;
@property (nonatomic, strong) NSString *definition;
@end

@interface BoFangResultItemsYiQianModel : BaseModel
@property (nonatomic, strong) BoFangResultItemsThreeTranscodeModel *transcode;
@property (nonatomic, strong) NSString *videoName;
@property (nonatomic, strong) NSString *transcodeId;
@property (nonatomic, strong) NSString *vid;
@property (nonatomic, strong) NSString *definition;
@end
@interface BoFangResultItemsYiQianSanModel : BaseModel
@property (nonatomic, strong) BoFangResultItemsThreeTranscodeModel *transcode;
@property (nonatomic, strong) NSString *videoName;
@property (nonatomic, strong) NSString *transcodeId;
@property (nonatomic, strong) NSString *vid;
@property (nonatomic, strong) NSString *definition;
@end


@interface BoFangResultItemsThreeTranscodeModel : BaseModel
@property (nonatomic, strong) NSArray *urls;
@property (nonatomic, strong) NSString *height;
@property (nonatomic, strong) NSString *width;
@property (nonatomic, strong) NSString *size;
@property (nonatomic, strong) NSString *transcodeId;
@property (nonatomic, strong) NSString *videoName;
@property (nonatomic, strong) NSString *duration;
@property (nonatomic, strong) NSString *path;
@end
@interface BoFangResultItemsThreeTranscodeUrlsModel : BaseModel
@property(nonatomic,strong)NSString*Ling;

@end


