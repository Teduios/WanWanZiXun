//
//  RoomListModel.m
//  Day07_GameLive
//
//  Created by jiyingxin on 15/10/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RoomListModel.h"

@implementation RoomListModel
+(id)parse:(NSDictionary *)responseObj{
    RoomListModel *model=[super parse:responseObj];
    NSMutableArray *arr=[NSMutableArray new];
    for (NSDictionary *dic in responseObj[@"data"]) {
        [arr addObject:[RoomListDataModel parse:dic]];
    }
    model.data = [arr copy];
    return model;
}
@end

@implementation RoomListDataModel
@end










