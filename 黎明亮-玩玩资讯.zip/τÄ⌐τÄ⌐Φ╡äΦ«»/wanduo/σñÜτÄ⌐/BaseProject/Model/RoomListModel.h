//
//  RoomListModel.h
//  Day07_GameLive
//
//  Created by jiyingxin on 15/10/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@interface RoomListModel : BaseModel
@property(nonatomic,strong) NSArray *data;
@end
/*
 "cate_id": "1",
 "fans": "35966",
 "game_name": "英雄联盟",
 "game_url": "/directory/game/LOL",
 "nickname": "官方赛事直播",
 "online": 309280,
 "owner_uid": "5596497",
 "room_id": "179989",
 "room_name": "[官方]英雄联盟S5总决赛八强赛第一天",
 "room_src": "http://staticlive.douyutv.com/upload/web_pic/9/179989_1510161015_thumb.jpg",
 "show_status": "1",
 "show_time": "1444922456",
 "specific_catalog": "riots5",
 "specific_status": "1",
 "subject": "",
 "url": "/riots5",
 "vod_quality": "0"
 */
@interface RoomListDataModel : BaseModel
@property(nonatomic,strong) NSString *cate_id;
@property(nonatomic,strong) NSString *fans;
@property(nonatomic,strong) NSString *game_name;
@property(nonatomic,strong) NSString *game_url;
@property(nonatomic,strong) NSString *nickname;
@property(nonatomic,strong) NSNumber *online;
@property(nonatomic,strong) NSString *owner_uid;
@property(nonatomic,strong) NSString *room_id;
@property(nonatomic,strong) NSString *room_name;
@property(nonatomic,strong) NSString *room_src;
@property(nonatomic,strong) NSString *show_status;
@property(nonatomic,strong) NSString *show_time;
@property(nonatomic,strong) NSString *specific_catalog;
@property(nonatomic,strong) NSString *specific_status;
@property(nonatomic,strong) NSString *subject;
@property(nonatomic,strong) NSString *url;
@property(nonatomic,strong) NSString *vod_quality;
@end












