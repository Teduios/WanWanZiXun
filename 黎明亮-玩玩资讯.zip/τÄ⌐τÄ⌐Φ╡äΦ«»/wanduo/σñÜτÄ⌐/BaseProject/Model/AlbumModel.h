//
//  AlbumModel.h
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"
//自己去github搜索 MJExtension，看具体用法
//MJExtension 使用数据解析的
/*
 "pageNum": 1,
	"pageSize": 10,
	"totalPage": 80,
	"totalRecord": 797
 */
@interface AlbumModel : BaseModel

@property(nonatomic,strong) NSArray *data;
@property(nonatomic,strong) NSNumber *pageNum;
@property(nonatomic,strong) NSNumber *totalPage;
@property(nonatomic,strong) NSNumber *pageSize;
@property(nonatomic,strong) NSNumber *totalRecord;

@end

@interface AlbumDataModel : BaseModel

@property(nonatomic,strong) NSString *clicks;
@property(nonatomic,strong) NSString *commentCount;
@property(nonatomic,strong) NSString *coverHeight;
@property(nonatomic,strong) NSString *coverUrl;
@property(nonatomic,strong) NSString *coverWidth;
@property(nonatomic,strong) NSString *created;
@property(nonatomic,strong) NSString *desc;
@property(nonatomic,strong) NSString *destUrl;
@property(nonatomic,strong) NSString *galleryId;
@property(nonatomic,strong) NSString *modify_time;
@property(nonatomic,strong) NSString *picsum;
@property(nonatomic,strong) NSString *title;
@property(nonatomic,strong) NSString *updated;


@end













