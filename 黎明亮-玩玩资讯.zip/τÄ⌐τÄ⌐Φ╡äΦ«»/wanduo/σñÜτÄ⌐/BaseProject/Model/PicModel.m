//
//  PicModel.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/19.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicModel.h"

@implementation PicModel

+ (NSDictionary *)objectClassInArray{
    return @{@"pictures" : [PicPicturesModel class]};
}
+(NSDictionary*)replacedKeyFromPropertyName{

    return @{@"desc":@"description"};
}
@end



@implementation PicPicturesModel

@end


