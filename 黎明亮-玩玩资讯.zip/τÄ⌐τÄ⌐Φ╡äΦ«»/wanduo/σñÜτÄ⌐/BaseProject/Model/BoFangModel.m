//
//  BoFangModel.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BoFangModel.h"

@implementation BoFangModel

@end
@implementation BoFangResultModel



@end
@implementation BoFangResultItemsModel

+(NSDictionary*)replacedKeyFromPropertyName{
    return @{@"Three":@"300",@"YiQianThree":@"1300",@"YiQian":@"1000"};

}

@end
@implementation BoFangResultItemsThreeModel



@end
@implementation BoFangResultItemsYiQianModel



@end
@implementation BoFangResultItemsYiQianSanModel



@end
@implementation BoFangResultItemsThreeTranscodeModel

//+(NSDictionary*)objectClassInArray{
//    return @{@"urls":[BoFangResultItemsThreeTranscodeUrlsModel class]};
//}
//
//@end
//@implementation BoFangResultItemsThreeTranscodeUrlsModel
//+(NSDictionary*)replacedKeyFromPropertyName{
//    return @{@"Ling":@"0"};
//}


@end