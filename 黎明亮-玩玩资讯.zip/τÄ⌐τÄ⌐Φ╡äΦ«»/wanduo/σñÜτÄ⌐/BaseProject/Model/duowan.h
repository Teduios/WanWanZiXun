//
//  duowan.h
//  BaseProject
//
//  Created by apple－jd08 on 15/10/30.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "BaseModel.h"

@interface duowan : BaseModel
@property (nonatomic, assign) double pageSize;
@property (nonatomic, strong) NSArray *data;
@property (nonatomic, strong) NSArray *headerline;
@property (nonatomic, strong) NSString *order;
@property (nonatomic, strong) NSString *totalRecord;
@property (nonatomic, strong) NSString *msg;
@property (nonatomic, assign) BOOL rs;
@property (nonatomic, assign) double totalPage;
@property (nonatomic, assign) double pageNum;
@end


@interface duowandata : BaseModel
@property (nonatomic, strong) NSString *dataIdentifier;
@property (nonatomic, strong) NSString *commentUrl;
@property(nonatomic,strong)NSNumber*ID;
@property (nonatomic, strong) NSString *destUrl;
@property (nonatomic, assign) long long time;
@property (nonatomic, strong) NSString *weight;
@property (nonatomic, strong) NSString *type;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, assign) double commentSum;
@property (nonatomic, strong) NSString *srcPhoto;
@property (nonatomic, strong) NSString *readCount;
@property (nonatomic, strong) NSString *artId;
@property (nonatomic, assign) double hasVideo;
@property (nonatomic, strong) NSString *photo;
@property (nonatomic, strong) NSString *content;



@end

@interface duowanheaderLine : BaseModel
@property (nonatomic, strong) NSString *weight;
@property (nonatomic, strong) NSString *commentUrl;
@property (nonatomic, strong) NSNumber *ID;
@property (nonatomic, strong) NSString *destUrl;
@property (nonatomic, strong) NSString *photo;
@property (nonatomic, strong) NSString *artId;
@property (nonatomic, strong) NSString *commentSum;

@end



