//
//  newestModel.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "newestModel.h"




@implementation newestModel
+(NSDictionary*)replacedKeyFromPropertyName{
    
    return @{@"coverUrl":@"cover_url",@"letvVideoUnique":@"letv_video_unique",@"letvVideoId":@"letv_video_id",@"amountPlay":@"amount_play",@"isRecommd":@"is_recommd",@"topLeftFlag":@"top_left_flag",@"uploadTime":@"upload_time",@"videoId":@"video_id",@"videoLength":@"video_length"};
}

@end
