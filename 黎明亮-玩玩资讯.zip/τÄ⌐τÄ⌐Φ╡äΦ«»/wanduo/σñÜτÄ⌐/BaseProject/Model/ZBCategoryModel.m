//
//  ZBCategoryModel.m
//  BaseProject
//
//  Created by jiyingxin on 15/11/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ZBCategoryModel.h"

@implementation ZBCategoryModel

@end
