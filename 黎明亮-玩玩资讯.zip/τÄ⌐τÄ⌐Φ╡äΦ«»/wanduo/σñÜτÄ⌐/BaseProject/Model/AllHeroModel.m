//
//  AllHeroModel.m
//  BaseProject
//
//  Created by jiyingxin on 15/11/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AllHeroModel.h"

@implementation AllHeroModel

+ (NSDictionary *)objectClassInArray{
    return @{@"all" : [AllHeroAllModel class]};
}
@end



@implementation AllHeroAllModel

@end


