//
//  FenLeiModel.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FenLeiModel.h"

@implementation FenLeiModel

+(NSDictionary*)objectClassInArray{

    return @{@"subCategory":[FenLeiSubModel class]};
}


@end
@implementation FenLeiSubModel



@end