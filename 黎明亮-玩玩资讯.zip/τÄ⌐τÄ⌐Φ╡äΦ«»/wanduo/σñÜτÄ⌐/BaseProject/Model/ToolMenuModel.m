//
//  ToolMenuModel.m
//  BaseProject
//
//  Created by jiyingxin on 15/11/2.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ToolMenuModel.h"

@implementation ToolMenuModel

@end


