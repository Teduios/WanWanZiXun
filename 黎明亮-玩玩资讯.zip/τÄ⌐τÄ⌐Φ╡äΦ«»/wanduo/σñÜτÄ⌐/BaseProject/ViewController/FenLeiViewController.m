//
//  FenLeiViewController.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FenLeiViewController.h"
#import "fenlei2ViewModel.h"
#import "FenlLeiAllViewController.h"
@implementation FenLei2Cell
- (UILabel *)nameLb {
    if(_nameLb == nil) {
        _nameLb = [[UILabel alloc] init];
        _nameLb.font = [UIFont systemFontOfSize:14];
        _nameLb.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_nameLb];
        [_nameLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.bottom.right.mas_equalTo(0);
        }];
    }
    return _nameLb;
}

- (TRImageView *)iconView {
    if(_iconView == nil) {
        _iconView = [[TRImageView alloc] init];
        [self.contentView addSubview:_iconView];
        [_iconView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.top.mas_equalTo(0);
            make.height.mas_equalTo(_iconView.mas_width);
        }];
    }
    return _iconView;
}
@end

@interface FenLeiViewController ()<UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property(nonatomic,strong)fenlei2ViewModel*fenleiVM;
@property(nonatomic,strong) UICollectionView *collectionView;
@end

@implementation FenLeiViewController


-(void)viewDidLoad{
    
    [super viewDidLoad];
    [self.collectionView.header beginRefreshing];
}

#pragma mark - UICollectionViewDataSource
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
  return self.fenleiVM.rowNumber;

}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    if (section==0) {
        return 4;
    }else if (section==1){
        
        return 8;
    }else if (section==2){
        
        return 8;
    }
    else if (section==3){
        
        return 8;
    }
    
    return 13;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    FenLei2Cell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    [cell.iconView.imageView setImageWithURL:[self.fenleiVM urlForS:indexPath.section ForRow:indexPath.row]];
    cell.nameLb.text = [self.fenleiVM nameForS:indexPath.section ForRow:indexPath.row];
    return cell;
}
#pragma mark - UICollectionViewDataDelegate
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section{
    if(section==0){
        return CGSizeMake(320, 3);
    }
    
    return CGSizeMake(320, 15);
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    FenlLeiAllViewController*vc=[[FenlLeiAllViewController alloc]initWithTag:[self.fenleiVM tagForS:indexPath.section ForRow:indexPath.row]];
    [self.navigationController pushViewController:vc animated:YES];
    
}
#pragma mark - UICollectionViewDelegateFlowLayout
/** section的上下左右边距 */
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(5, 10, 5, 10);
}
/** 最小行间距 */
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 5;
}

/** 每格cell的 宽高 */
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat width = (kWindowW - 5 * 10) / 4;
    CGFloat height = width + 17;
    return CGSizeMake(width, height);
}




-(fenlei2ViewModel*)fenleiVM{
    if (!_fenleiVM) {
        _fenleiVM=[fenlei2ViewModel new];
    }
    return _fenleiVM;
}
- (UICollectionView *)collectionView {
    if(_collectionView == nil) {
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:[UICollectionViewFlowLayout new]];
        [self.view addSubview:_collectionView];
        _collectionView.backgroundColor = [UIColor whiteColor];
        [_collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.header=[MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self.fenleiVM getDataFromNetCompleteHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }
                else{
                    [_collectionView reloadData];
                }
                [_collectionView.header endRefreshing];
            }];
        }];
        [_collectionView registerClass:[FenLei2Cell class] forCellWithReuseIdentifier:@"Cell"];
    }
    return _collectionView;
}
@end
