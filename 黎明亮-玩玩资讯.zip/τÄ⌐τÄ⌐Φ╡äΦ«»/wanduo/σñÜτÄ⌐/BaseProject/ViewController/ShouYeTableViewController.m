//
//  ShouYeTableViewController.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/14.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ShouYeTableViewController.h"
#import "TwoViewController.h"
#import "MissViewController.h"
#import "XuLaoShiViewController.h"
#import "ChangViewController.h"
#import "ShiPin2ViewController.h"
#import "LOLxiaoshViewController.h"
#import "BaiKeViewController.h"
#import "SearchViewController.h"
#import "HerosViewController.h"
#import "SkinViewController.h"

@interface ShouYeTableViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *image1;
@property (weak, nonatomic) IBOutlet UIButton *btn1;
@property (weak, nonatomic) IBOutlet UIButton *btn2;
@property (weak, nonatomic) IBOutlet UIButton *btn;
@property (weak, nonatomic) IBOutlet UIImageView *image2;
@property (weak, nonatomic) IBOutlet UIImageView *image3;

@end

@implementation ShouYeTableViewController

- (IBAction)ZhiXun:(UIButton *)sender {
    TwoViewController*vc=[TwoViewController new];
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)Miss:(id)sender {
    MissViewController*vc=[MissViewController new];
    [self.navigationController pushViewController: vc animated:YES];
}
- (IBAction)XuLaoShi:(id)sender {
    
    XuLaoShiViewController*vc=[XuLaoShiViewController new];
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)Chang:(id)sender {
    ChangViewController*vc=[ChangViewController new];
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)XiaoShue:(id)sender {
    LOLxiaoshViewController*vc=[LOLxiaoshViewController new];
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)chazhanji:(id)sender {
    SearchViewController*vc=[SearchViewController new];
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)baike:(id)sender {
    BaiKeViewController*vc=[BaiKeViewController new];
    [self.navigationController pushViewController: vc animated:YES];
}
- (IBAction)yingXiong:(id)sender {
    HerosViewController*vc=[HerosViewController new];
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)pifu:(id)sender {
    SkinViewController*vc=[SkinViewController new];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self tableView];
    

    self.image1.layer.cornerRadius=25;
    self.image1.layer.masksToBounds = YES;
    self.image2.layer.cornerRadius=25;
    self.image2.layer.masksToBounds = YES;
    self.image3.layer.cornerRadius=25;
    self.image3.layer.masksToBounds = YES;
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

@end
