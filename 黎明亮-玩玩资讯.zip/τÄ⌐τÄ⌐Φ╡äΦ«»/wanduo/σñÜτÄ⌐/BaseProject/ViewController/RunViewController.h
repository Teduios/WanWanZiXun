//
//  RunViewController.h
//  BaseProject
//
//  Created by apple－jd08 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RunViewController : UIViewController

@end
@interface Run2Cell : UICollectionViewCell
@property(nonatomic,strong) UILabel *nameLb;
@end