//
//  RunViewController.m
//  BaseProject
//
//  Created by apple－jd08 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RunViewController.h"
#import "RunViewModel.h"
#import "RunCell.h"
@implementation Run2Cell
- (UILabel *)nameLb {
    if(_nameLb == nil) {
        _nameLb = [[UILabel alloc] init];
        _nameLb.backgroundColor=[UIColor grayColor];
        _nameLb.textAlignment = NSTextAlignmentLeft;
        [self.contentView addSubview:_nameLb];
        [_nameLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.bottom.right.top.mas_equalTo(0);
        }];
    }
    return _nameLb;
}
@end
@interface RunViewController ()<UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>
@property(nonatomic,strong) UICollectionView *collectionView;
@property(nonatomic,strong)RunViewModel*runVM;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong)NSArray*arr;
@property (weak, nonatomic) IBOutlet UIButton *btn;
@property(nonatomic,strong)NSNumber*num;
@end

@implementation RunViewController
-(NSArray*)arr{
    if (!_arr) {
        _arr=@[@1,@2,@3];

    }
    return _arr;
}

- (IBAction)btna:(id)sender {
    self.collectionView.hidden=NO;
    [self.collectionView.header beginRefreshing];

}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return 3;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    Run2Cell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    
    cell.nameLb.text = [NSString stringWithFormat:@"%@级",self.arr[indexPath.row]];
    return cell;
}
#pragma mark - UICollectionViewDataDelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    self.collectionView.hidden=YES;
    self.num=self.arr[indexPath.row];

    [self.btn setTitle:[NSString stringWithFormat:@"%@级",self.num] forState:0];
    [self.tableView reloadData];
}

#pragma mark - UICollectionViewDelegateFlowLayout
/** section的上下左右边距 */
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(200, 20, 5, 20);
}
/** 最小行间距 */
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 0;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat width = kWindowW /2+50;
    CGFloat height =30;
    return CGSizeMake(width, height);
}
- (UICollectionView *)collectionView {
    if(_collectionView == nil) {
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:[UICollectionViewFlowLayout new]];
        [self.view addSubview:_collectionView];
        _collectionView.backgroundColor = [UIColor clearColor];
        [_collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        [_collectionView registerClass:[Run2Cell class] forCellWithReuseIdentifier:@"Cell"];
    }
    return _collectionView;
}

-(RunViewModel*)runVM{
    if (!_runVM) {
        _runVM=[RunViewModel new];
    }
    return _runVM;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.runVM.rowNumber;
    
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    RunCell*cell=[tableView dequeueReusableCellWithIdentifier:@"Cell"];
    NSInteger myin=[self.num integerValue];
    cell.nameLb.text=[self.runVM nameForRow:indexPath.row];
    cell.rowLb.text=[NSString stringWithFormat:@"%@级",self.num];
    cell.iplevLb.text=[self.runVM iplevForRow:indexPath.row][myin-1];
    
    cell.levLb.text=[self.runVM levForRow:indexPath.row][myin-1];
    cell.propLb.text=[self.runVM propForRow:indexPath.row];
    return cell;
}





- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.header=[MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.runVM getDataFromNetCompleteHandle:^(NSError *error) {
            [self.tableView reloadData];
            [self.tableView.header endRefreshing];
        }];
    }];
    self.num=@(1);
    self.tableView.backgroundColor=[UIColor grayColor];
    [self.tableView.header beginRefreshing];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
