//
//  photoViewController.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/4.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "photoViewModel.h"
@interface photoViewController : UIViewController
@property(nonatomic)AlbumType type;
@end
