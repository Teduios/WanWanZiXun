//
//  HeroDetailViewController.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HeroDetailViewController.h"
#import "HeroDetailViewModel.h"
#import "TRImageView.h"
#import "BaiKeNetManager.h"
@interface HeroDetailCell : UITableViewCell
@property(nonatomic,strong) UILabel *descLb;
@property(nonatomic,strong)TRImageView*iconV;
@property(nonatomic,strong)UIView*grayView;
@property(nonatomic,strong)UIView*whiteView;
@end
@implementation HeroDetailCell
- (UILabel *)descLb{
    if (!_descLb) {
        _descLb = [UILabel new];
        _descLb.font=[UIFont systemFontOfSize:14];
        //黑线方框背景，正常由美工提供。 如果没有美工 可以考虑使用灰色视图套白色视图，两者边缘差距1像素来解决
        _grayView = [UIView new];
        _grayView.backgroundColor=[UIColor lightGrayColor];
        [self.contentView addSubview:_grayView];
        _grayView.layer.cornerRadius = 4;
        [_grayView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(UIEdgeInsetsMake(3, 10, 3, 10));
        }];
        
        _whiteView =[UIView new];
        _whiteView.backgroundColor = [UIColor whiteColor];
        [_grayView addSubview:_whiteView];
        _whiteView.layer.cornerRadius = 4;
        
        [_whiteView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(UIEdgeInsetsMake(1, 1, 1, 1));
            make.height.mas_greaterThanOrEqualTo(28);
        }];
        
        [_whiteView addSubview:_descLb];
      
        _descLb.numberOfLines = 0;
        [_descLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(10);
            make.bottom.right.mas_equalTo(-10);
            make.left.mas_equalTo(70);
            make.height.mas_greaterThanOrEqualTo(50);
        }];
        
    }
    return _descLb;
}

-(TRImageView*)iconV{

    if (!_iconV) {
        _iconV=[TRImageView new];
        [_whiteView addSubview:_iconV];
        
        [_iconV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.mas_equalTo(10);
            make.size.mas_equalTo(CGSizeMake(50, 50));
        }];
    }
    return _iconV;
}


- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.contentView.backgroundColor=[UIColor clearColor];
        self.backgroundColor=[UIColor clearColor];
    }
    return self;
}

@end


@interface HeroDetailViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)HeroDetailViewModel*heroDetailVM;
@property(nonatomic,strong)UITableView*tableView;
@property(nonatomic,strong)UIView*topView;
@end

@implementation HeroDetailViewController

-(id)initWithHeroName:(AllHeroModel *)allModel{
    if (self=[super init]) {
        self.allModel=allModel;
        self.title=@"英雄详情";
    }
    return self;
}

-(HeroDetailViewModel*)heroDetailVM{
    if (!_heroDetailVM) {
        _heroDetailVM=[[HeroDetailViewModel alloc]initWithHeroName:_allModel.enName];
    }
    return _heroDetailVM;
}

- (UIView *)topView {
    if(_topView == nil) {
        _topView = [[UIView alloc] init];
        _topView.backgroundColor=[UIColor whiteColor];
        [self.view addSubview:_topView];
        [_topView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.right.mas_equalTo(0);
            make.height.mas_equalTo(90);
        }];

        TRImageView *imageView = [TRImageView new];
        [_topView addSubview:imageView];
        NSURL *iconURL = [NSURL URLWithString:[NSString stringWithFormat:@"http://img.lolbox.duowan.com/champions/%@_120x120.jpg", _allModel.enName]];
        [imageView.imageView setImageWithURL:iconURL placeholderImage:[UIImage imageNamed:@"cell_bg_noData_5"]];
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.size.mas_equalTo(CGSizeMake(60, 60));
            make.left.top.mas_equalTo(8);
        }];

        UILabel *abilityLb=[UILabel new];
        abilityLb.text = _allModel.title;
        [_topView addSubview:abilityLb];
        [abilityLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(imageView.mas_right).mas_equalTo(10);
            make.right.mas_equalTo(-10);
            make.topMargin.mas_equalTo(imageView);
        }];
        

        UILabel *levelLb=[UILabel new];
        NSArray*price=[_allModel.price componentsSeparatedByString:@","];
        
        levelLb.text = [NSString stringWithFormat:@"%@  %@",
                        [@"金 " stringByAppendingString:price.firstObject],[@"卷" stringByAppendingString:price.lastObject]];
        
        levelLb.font=[UIFont systemFontOfSize:12];
        levelLb.textColor=[UIColor lightGrayColor];
        [_topView addSubview:levelLb];
        [levelLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.rightMargin.mas_equalTo(abilityLb);
            make.top.mas_equalTo(abilityLb.mas_bottom).mas_equalTo(5);
        }];

        UILabel *coolLb=[UILabel new];
 NSArray*rating=[_allModel.rating componentsSeparatedByString:@","];
        coolLb.text = [NSString stringWithFormat:@"%@ %@ %@ %@",
                       [@"攻 " stringByAppendingString:rating[0]],
                       [@"防 " stringByAppendingString:rating[1]],
                       [@"法 " stringByAppendingString:rating[2]],
                       [@"难度 " stringByAppendingString:rating[3]]] ;
        coolLb.font=[UIFont systemFontOfSize:12];
        coolLb.textColor=[UIColor lightGrayColor];
        [_topView addSubview:coolLb];
        [coolLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.leftMargin.rightMargin.mas_equalTo(abilityLb);
            make.top.mas_equalTo(levelLb.mas_bottom).mas_equalTo(5);
        }];
        
    }
    return _topView;
}


- (UITableView *)tableView {
    if(_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [UIView new];
        _tableView.backgroundColor = [UIColor clearColor];
        _tableView.allowsSelection = NO;
        _tableView.separatorStyle = 0;
        [self.view addSubview:_tableView];
        _tableView.sectionHeaderHeight = 23;
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.bottom.right.mas_equalTo(0);
            make.top.mas_equalTo(self.topView.mas_bottom).mas_equalTo(0);
        }];
        
        _tableView.header=[MJRefreshNormalHeader headerWithRefreshingBlock:^{
          [  self.heroDetailVM getDataFromNetCompleteHandle:^(NSError *error) {
              [_tableView reloadData];
              [_tableView.header endRefreshing];
          }];
        }];
        
        [_tableView registerClass:[HeroDetailCell class] forCellReuseIdentifier:@"Cell"];
    }
    return _tableView;
}


#pragma mark - UITableViewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 5;
 
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==0||section==1) {
        return 2;
    }
    
    return 1;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *view = [UIView new];
    view.backgroundColor = self.view.backgroundColor;
    UILabel *lb = [UILabel new];
    [view addSubview:lb];
    lb.backgroundColor = [UIColor clearColor];
    lb.text = @[@"最佳搭档", @"最佳克制", @"使用" ,@"应对" ,@"英雄背景"][section];
    lb.font = [UIFont systemFontOfSize:13];
    lb.textColor=[UIColor lightGrayColor];
    [lb mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(10);
        make.centerY.mas_equalTo(0);
    }];
    return view;
}
- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewAutomaticDimension;
}

-( UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    HeroDetailCell*cell=[tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (indexPath.section==0) {
        for(int i=0;i<2;i++){
            if (indexPath.row==i) {
            HeroDetailLikeModel*abc=(HeroDetailLikeModel*)[self.heroDetailVM modelForRow].like[i];
            cell.descLb.text=abc.des;
            [cell.iconV.imageView setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://img.lolbox.duowan.com/champions/%@_120x120.jpg",abc.partner]]];
            }}}
    if (indexPath.section==1) {
        for(int i=0;i<2;i++){
            if (indexPath.row==i) {
                HeroDetailLikeModel*abc=(HeroDetailLikeModel*)[self.heroDetailVM modelForRow].hate[i];
                cell.descLb.text=abc.des;
                [cell.iconV.imageView setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://img.lolbox.duowan.com/champions/%@_120x120.jpg",abc.partner]]];
            }}}

    if (indexPath.section==2) {
        cell.descLb.text=[self.heroDetailVM tipForRow];
         [cell.iconV.imageView setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://img.lolbox.duowan.com/champions/%@_120x120.jpg",_allModel.enName]]];
    }
    
    if (indexPath.section==3) {
        cell.descLb.text=[self.heroDetailVM opponenTipsForRow];
         [cell.iconV.imageView setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://img.lolbox.duowan.com/champions/%@_120x120.jpg",_allModel.enName]]];
    }
    if (indexPath.section==4) {
        cell.descLb.text=[self.heroDetailVM descForRow];
        [cell.iconV.imageView setImageWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://img.lolbox.duowan.com/champions/%@_120x120.jpg",_allModel.enName]]];
    }
   
    return cell;
}


- (void)viewDidLoad {
    [super viewDidLoad];

    self.tableView.backgroundColor=[UIColor whiteColor];
    [self.tableView.header beginRefreshing];
}







- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
