//
//  HeroDetailViewController.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AllHeroModel.h"
@interface HeroDetailViewController : UIViewController
-(id)initWithHeroName:(AllHeroAllModel*)allModel;
@property(nonatomic,strong)AllHeroAllModel*allModel;
@end
