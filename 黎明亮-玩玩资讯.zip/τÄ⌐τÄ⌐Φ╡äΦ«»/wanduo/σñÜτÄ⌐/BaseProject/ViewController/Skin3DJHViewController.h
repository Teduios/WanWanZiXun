//
//  Skin3DJHViewController.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Skin3DJHViewController : UIViewController
-(id)initWithenName:(NSString*)enName title:(NSString*)title;
@property(nonatomic,strong)NSString*enName;
@end
