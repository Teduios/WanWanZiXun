//
//  ViewController.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/22.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ViewController.h"
#import "duowanViewModel.h"

#import "ScrollDisplayViewController.h"
#import "threeViewController.h"


@interface ViewController ()<UITableViewDataSource,UITableViewDelegate,ScrollDisplayViewControllerDelegate>
@property(nonatomic,strong)duowanViewModel*duowanVM;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property(nonatomic,strong)ScrollDisplayViewController*sdVC;

@end

@implementation ViewController

-(duowanViewModel*)duowanVM{

    if (!_duowanVM) {
        _duowanVM=[[duowanViewModel alloc]initWithDuoWanType:_type];
    }
    return _duowanVM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
_tableView.header=[MJRefreshNormalHeader headerWithRefreshingBlock:^{
    [self.duowanVM refreshDataCompletionHandle:^(NSError *error) {
        [_tableView.header endRefreshing];
        [_tableView reloadData];
        [self configTableHeader];
    }];
}];
    [self.tableView.header beginRefreshing];
    _tableView.footer=[MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self.duowanVM getMoreDataCompletionHandle:^(NSError *error) {
            if (error) {
                [self showErrorMsg:error.description];
            }
       [_tableView.header beginRefreshing];

        }];
    }];
    

    
}
-(void)configTableHeader{
    
    if (self.duowanVM.headImageURLs.count==0) {
        return;
    }
    
    
    UIView *headerView=[[UIView alloc]initWithFrame:CGRectMake(0, 0, 0, 185)];
    [_sdVC removeFromParentViewController];
    
    NSMutableArray*arr=[NSMutableArray new];
    for(duowanheaderLine*model in self.duowanVM.headImageURLs){
        
        [arr addObject:[NSURL URLWithString:model.photo]];
        
    }
    
    _sdVC=[[ScrollDisplayViewController alloc]initWithImagePaths:arr];
    _sdVC.delegate=self;
    [self addChildViewController:_sdVC];
    [headerView addSubview:_sdVC.view];
    [_sdVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(headerView);
    }];
    _tableView.tableHeaderView=headerView;
    
}
-(void)ScrollDisplayViewController:(ScrollDisplayViewController *)ScrollDisplayViewController didSelectedIndex:(NSInteger)index{
    threeViewController*vc=[[threeViewController alloc]initWithID:[self.duowanVM adIDForRow:index]];
    [self.navigationController pushViewController:vc animated:YES];

}



-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.duowanVM.rowNumber;

}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"Cell"];

    UIImageView*imageView=(UIImageView*)[cell.contentView viewWithTag:100];
    UILabel*titlelabel=(UILabel*)[cell.contentView viewWithTag:200];
    UILabel*readplay=(UILabel*)[cell.contentView viewWithTag:300];
UILabel*content=(UILabel*)[cell.contentView viewWithTag:400];
    UILabel*uptime=(UILabel*)[cell.contentView viewWithTag:500];
    [imageView setImageWithURL:[self.duowanVM iconURLForRow:indexPath.row]];
   titlelabel.text=[self.duowanVM titleForRow:indexPath.row];
//    cell.contentlabel.text=[self.duowanVM contentForRow:indexPath.row];
   readplay.text=[self.duowanVM readCountForRow:indexPath.row];
    content.text=[self.duowanVM contentForRow:indexPath.row];
    uptime.text=[self.duowanVM timeForRow:indexPath.row];
    
    
    
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 75;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    threeViewController*vc=[[threeViewController alloc]initWithID:[self.duowanVM IDForRow:indexPath.row]];
    [self.navigationController pushViewController:vc animated:YES];

}
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
