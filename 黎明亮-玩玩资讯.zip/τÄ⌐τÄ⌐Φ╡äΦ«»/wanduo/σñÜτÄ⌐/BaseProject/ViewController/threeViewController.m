//
//  threeViewController.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "threeViewController.h"

@interface threeViewController ()<UIWebViewDelegate>
@property(nonatomic,strong)NSNumber*ID;
@end

@implementation threeViewController
-(id)initWithID:(NSNumber *)ID{
    if (self=[super init]) {
        self.ID=ID;
    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    UIWebView*webView=[UIWebView new];
    [self.view addSubview:webView];
    [webView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager GET:[NSString stringWithFormat:@"http://box.dwstatic.com/apiNewsList.php?action=d&newsId=%@",_ID] parameters:nil success:^(NSURLSessionDataTask * task, id responseObject) {

    } failure:^(NSURLSessionDataTask * _Nonnull task, NSError * _Nonnull error) {
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:error.userInfo[@"com.alamofire.serialization.response.error.data"] options:NSJSONReadingAllowFragments error:nil];
        [webView loadHTMLString:dict[@"data"][@"content"] baseURL:nil];
    }];

    webView.delegate = self;

}
- (void)webViewDidStartLoad:(UIWebView *)webView{
    [self showProgress]; //旋转提示
}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    [self hideProgress];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    [self hideProgress];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
