//
//  SkinViewController.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "SkinViewController.h"
#import "AllheroViewModel.h"
#import "Skin3DJHViewController.h"

@interface SkinViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView*tableView;
@property(nonatomic,strong)AllheroViewModel*allHeroVM;
@end

@implementation SkinViewController

-(AllheroViewModel*)allHeroVM{

    if (!_allHeroVM) {
        _allHeroVM=[AllheroViewModel new];
        
    }
    return _allHeroVM;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return self.allHeroVM.rowNumber;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"Cell"];
    cell.textLabel.text=[self.allHeroVM titleForRow:indexPath.row];
    cell.accessoryType=1;
    return cell;
}



- (void)viewDidLoad {
    [super viewDidLoad];
 self.title=@"英雄名称";
    [self.tableView.header beginRefreshing];
}


- (UITableView *)tableView {
    if(_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tableFooterView = [UIView new];
        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        _tableView.header=[MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self.allHeroVM getDataFromNetCompleteHandle:^(NSError *error) {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    [_tableView reloadData];
                }
                [_tableView.header endRefreshing];
            }];
        }];
    }
    return _tableView;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    Skin3DJHViewController*vc=[[Skin3DJHViewController alloc]initWithenName:[self.allHeroVM enNamesForRow:indexPath.row] title:[self.allHeroVM titleForRow:indexPath.row]];
    [self.navigationController pushViewController:vc animated:YES];

}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}





/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
