//
//  Skin3DJHViewController.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "Skin3DJHViewController.h"
#import "iCarousel.h"
#import "HerokinViewModel.h"
#import "TRImageView.h"


@interface Skin3DJHViewController ()<iCarouselDelegate,iCarouselDataSource>
@property(nonatomic,strong)HerokinViewModel *picsVM;
@property(nonatomic,strong)iCarousel *ic;
@property(nonatomic,strong)NSString*imagesPath;
@end

@implementation Skin3DJHViewController

-(id)initWithenName:(NSString *)enName title:(NSString *)title{
    if (self=[super init]) {
        self.enName=enName;
        self.title=title;
    }
    return self;
}
- (id)init{
    if (self = [super init]) {
        NSAssert1(NO, @"%s 必须使用initWithAid方法初始化", __func__);
    }
    return self;
}

- (HerokinViewModel *)picsVM
{
    if (!_picsVM) {
        _picsVM = [[HerokinViewModel alloc]initWithTag:_enName];
    }
    return _picsVM;
}

-(iCarousel *)ic
{
    if (!_ic) {
        _ic = [[iCarousel alloc]init];
        _ic.delegate = self;
        _ic.dataSource = self;
        _ic.type = 7;
        // 翻页模式
        _ic.pagingEnabled = YES;
        // 改变为竖向展示
        //        _ic.vertical = YES;
        // 自动展示
        //        _ic.autoscroll = YES;
    }
    return _ic;
}
-(NSString *)imagesPath{
    if (!_imagesPath) {
        //希望所有图片存放在 ~/Documents/images 文件夹下
        NSString *docPath=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
        _imagesPath=[docPath stringByAppendingPathComponent:@"images"];
        //需要判断文件夹是否存在，如果不存在需要创建一个
        NSFileManager *manager=[NSFileManager defaultManager];
        if (![manager fileExistsAtPath:_imagesPath]) {
            [manager createDirectoryAtPath:_imagesPath withIntermediateDirectories:YES attributes:nil error:nil];
        }
    }
    return _imagesPath;
}

- (void)viewDidLoad {
    [super viewDidLoad];
 

    // 将图片显示到界面上
    self.ic.backgroundColor = [UIColor grayColor];
    [self.view addSubview:self.ic];
    
    [self.ic mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    [self.picsVM getDataFromNetCompleteHandle:^(NSError *error) {
        [self.ic reloadData];
    }];

    
    // 自动滚动
    //    [NSTimer bk_scheduledTimerWithTimeInterval:2 block:^(NSTimer *timer) {
    //        [self.ic scrollToItemAtIndex:self.ic.currentItemIndex + 1 animated:YES];
    //    } repeats:YES];
}


#pragma mark ----iCarouselDelegate,iCarouselDataSource

- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    return self.picsVM.rowNumber;
}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view
{
    NSString*imagePath=[self.picsVM smallimgForRow:index];
    NSString *lastComponent=imagePath.lastPathComponent;
    NSString *filePath=[self.imagesPath stringByAppendingPathComponent:lastComponent];
    NSFileManager *manager=[NSFileManager defaultManager];
    if ([manager fileExistsAtPath:filePath]) {
        UIImage *img=[UIImage imageWithContentsOfFile:filePath];
        UIImageView *imageView=[[UIImageView alloc] initWithImage:img];
        [_ic addSubview:imageView];
        
    }
    
    if (!view) {
        NSInteger width = kWindowW/2;
        NSInteger height = kWindowH/2;
        view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, width, height)];
        
        TRImageView *imageView = [TRImageView new];
        imageView.tag = 100;
        [view addSubview:imageView];
        imageView.contentMode = UIViewContentModeScaleAspectFill;
        
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
    }
    TRImageView *imageView = (TRImageView *)[view viewWithTag:100];
    [imageView.imageView setImageWithURL:[NSURL URLWithString:[self.picsVM smallimgForRow:index]]];
    return view;
    
}

- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index
{
    NSLog(@"点击了第%ld", (long)index);
}






/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
