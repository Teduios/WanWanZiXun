//
//  FMHeroViewController.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "FMHeroViewController.h"
#import "HeroViewModel.h"
#import "HeroDetailViewController.h"
@implementation FMHeroCell
-(TRImageView*)enNameView{
    if (!_enNameView) {
        _enNameView=[TRImageView new];
        [self.contentView addSubview:_enNameView];
        [_enNameView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.bottom.top.mas_equalTo(0);
            make.size.mas_equalTo(CGSizeMake(70, 70));
        }];
    }
    
    return _enNameView;
}

-(UILabel*)titleLb{
    if (!_titleLb) {
        _titleLb=[UILabel new];
        [self.contentView addSubview:_titleLb];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.enNameView.mas_right).mas_equalTo(7);
            make.top.mas_equalTo(self.enNameView.mas_top);
            make.right.mas_equalTo(0);
            make.bottom.mas_equalTo(self.cnNameLb.mas_top).mas_equalTo(-5);
        }];
    }
    
    
    return _titleLb;
}

-(UILabel*)cnNameLb{
    if (!_cnNameLb) {
        _cnNameLb=[UILabel new];
        [self.contentView addSubview:_cnNameLb];
        _cnNameLb.textColor=[UIColor grayColor];
        _cnNameLb.font=[UIFont systemFontOfSize:13];
        [_cnNameLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.mas_equalTo(self.titleLb);
            make.bottom.mas_equalTo(self.locationLb.mas_top).mas_equalTo(-5);
        }];
    }
    
    
    return _cnNameLb;
}


-(UILabel*)locationLb{
    if (!_locationLb) {
        _locationLb=[UILabel new];
        [self.contentView addSubview:_locationLb];
//        _locationLb.textColor=[UIColor blueColor];
        _locationLb.font=[UIFont systemFontOfSize:15];

        [_locationLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.mas_equalTo(self.enNameView.mas_bottom);
            make.left.mas_equalTo(self.titleLb.mas_left);
        }];
    }
    return _locationLb;
}


@end
@interface FMHeroViewController ()<UICollectionViewDelegateFlowLayout,UICollectionViewDataSource,UIBarPositioningDelegate>
@property(nonatomic,strong)HeroViewModel*heroVM;
@property(nonatomic,strong)UICollectionView*collectionView;
@end

@implementation FMHeroViewController
- (HeroViewModel *)heroVM {
    if(_heroVM == nil) {
        _heroVM =[HeroViewModel new];
    }
    return _heroVM;
}

- (UICollectionView *)collectionView {
    if(_collectionView == nil) {
        _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:[UICollectionViewFlowLayout new]];
        [self.view addSubview:_collectionView];
        _collectionView.backgroundColor = [UIColor whiteColor];
        [_collectionView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        _collectionView.delegate = self;
        _collectionView.dataSource = self;
        _collectionView.header=[MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self.heroVM getDataFromNetCompleteHandle:^(NSError *error)
             {
                if (error) {
                    [self showErrorMsg:error.localizedDescription];
                }else{
                    [_collectionView reloadData];
                }
                [_collectionView.header endRefreshing];
            }];
        }];
        [_collectionView registerClass:[FMHeroCell class] forCellWithReuseIdentifier:@"Cell"];
    }
    return _collectionView;
}


- (void)viewDidLoad {
    [super viewDidLoad];

    self.title=@"英雄";
 [self.collectionView.header beginRefreshing];

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return self.heroVM.rowNumber;
}
-(UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    FMHeroCell*cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    [cell.enNameView.imageView setImageWithURL:[self.heroVM enNameForRow:indexPath.row]];
    cell.cnNameLb.text=[self.heroVM cnNameForRow: indexPath.row];
    cell.titleLb.text=[self.heroVM titleForRow: indexPath.row];
    cell.locationLb.text=[self.heroVM locationForRow:indexPath.row];
    
    
    return cell;
}

#pragma mark - UICollectionViewDelegateFlowLayout
/** section的上下左右边距 */
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsMake(5, 10, 5, 10);
}
/** 最小行间距 */
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section{
    return 10;
}
//* 最小列间距、因为已经算出每个cell的宽度。 cell的列间距不用指定也会自动适配的
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section{
    return 10;
}
/** 每格cell的 宽高 */
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat width = (kWindowW - 3* 10) / 2;
    CGFloat height = 70;
    return CGSizeMake(width, height);
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    HeroDetailViewController*vc=[[HeroDetailViewController alloc]initWithHeroName:[self.heroVM modelForRow: indexPath.row]];
    [self.navigationController pushViewController:vc animated:YES];
    
}




@end
