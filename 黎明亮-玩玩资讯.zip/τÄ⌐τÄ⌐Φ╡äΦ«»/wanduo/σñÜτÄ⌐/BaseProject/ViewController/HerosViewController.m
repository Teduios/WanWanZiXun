//
//  HerosViewController.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/17.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "HerosViewController.h"
#import "FMHeroViewController.h"
#import "AllHeroViewController.h"
#import "ScrollDisplayViewController.h"
#define kWid kWindowW/3-30
@interface HerosViewController ()<ScrollDisplayViewControllerDelegate>
@property(nonatomic,strong)ScrollDisplayViewController*sdVC;
@property(nonatomic,strong)UIScrollView*scrollView;
@property(nonatomic,strong)NSMutableArray*btns;
@property(nonatomic,strong)UIView*lineView;
@property(nonatomic,strong)UIButton*currentBtn;
@end

@implementation HerosViewController
-(void)ScrollDisplayViewController:(ScrollDisplayViewController *)ScrollDisplayViewController currentIndex:(NSInteger)index{
    _currentBtn.selected=NO;
    _currentBtn=_btns[index];
    _currentBtn.selected=YES;
    [self.lineView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(kWid);
        make.height.mas_equalTo(2);
        make.centerX.mas_equalTo(_currentBtn);
        make.top.mas_equalTo(_currentBtn.mas_bottom).mas_equalTo(8);
    }];
    
}

-(NSMutableArray*)btns{
    if (!_btns) {
        _btns=[NSMutableArray new];
    }
    return _btns;
}


-(UIView*)lineView{
    if (!_lineView) {
        _lineView=[UIView new];
        _lineView.backgroundColor=kRGBColor(56, 106, 198);
    }
    return _lineView;
}

-(UIScrollView*)scrollView{
    if (!_scrollView) {
        _scrollView=[UIScrollView new];
        NSArray*arr=@[@"免费英雄",@"全部英雄"];
        UIView*lastView=nil;
        for(int i=0;i<arr.count;i++){
            UIButton*btn=[UIButton buttonWithType:0];
            [btn setTitle:arr[i] forState:0];
            [btn setTitleColor:kRGBColor(89, 89, 89) forState:UIControlStateNormal];
            [btn setTitleColor:self.lineView.backgroundColor forState:UIControlStateSelected];
            if (i==0) {
                _currentBtn=btn;
                btn.selected=YES;
            }
            [btn bk_addEventHandler:^(UIButton *sender) {
                if (_currentBtn!=sender) {
                    _currentBtn.selected=NO;
                    sender.selected=YES;
                    _currentBtn=sender;
                    [self.lineView mas_remakeConstraints:^(MASConstraintMaker *make) {
                        make.width.mas_equalTo(kWid);
                        make.height.mas_equalTo(2);
                        make.centerX.mas_equalTo(sender);
                        make.top.mas_equalTo(sender.mas_bottom).mas_equalTo(8);
                    }];
                    _sdVC.currentPage=[_btns indexOfObject:sender];
                }
            } forControlEvents:UIControlEventTouchUpInside];
            [_scrollView addSubview:btn];
            [btn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.size.mas_equalTo(CGSizeMake(kWid , 24));
                make.centerY.mas_equalTo(_scrollView);
                if (lastView) {
                    make.left.mas_equalTo(lastView.mas_right).mas_equalTo(10);
                    
                }else{
                    make.left.mas_equalTo(10);
                    
                }
                
                
            }];
            lastView=btn;
            [self.btns addObject:btn];
        }
        
        
        [lastView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(_scrollView.mas_right).mas_equalTo(-10);
        }];
        _scrollView.showsHorizontalScrollIndicator=NO;
        [_scrollView addSubview:self.lineView];
        [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.mas_equalTo(kWid);
            make.height.mas_equalTo(2);
            UIButton*btn=_btns[0];
            make.centerX.mas_equalTo(btn);
            make.top.mas_equalTo(btn.mas_bottom).mas_equalTo(8);
        }];
        
    }
    
    return _scrollView;
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    self.scrollView.hidden=NO;
    
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.scrollView.hidden=YES;
    
    
}


-(FMHeroViewController*)fmHero{
  FMHeroViewController*vc1=[kStoryboard(@"Main")instantiateViewControllerWithIdentifier:@"FMHeroViewController"];
    return vc1;
}
-(AllHeroViewController*)allHero{
AllHeroViewController*vc2=[kStoryboard(@"Main")instantiateViewControllerWithIdentifier:@"AllHeroViewController"];
    return vc2;
}
-(ScrollDisplayViewController*)sdVC{
    if (!_sdVC) {
      

    
        NSArray*vcs=@[[self fmHero],
                      [self allHero],];
        _sdVC=[[ScrollDisplayViewController alloc]initWithViewControllers:vcs];
        _sdVC.autoCycle=NO;
        _sdVC.showPathControl=NO;
        _sdVC.delegate=self;
    }
    
    return _sdVC;
    
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
// HerosViewController*vc=[HerosViewController ]
    
    

    [self addChildViewController:self.sdVC];
    [self.view addSubview:self.sdVC.view];
    [self.sdVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.top.mas_equalTo(44);
        make.bottom.left.right.mas_equalTo(0);
    }];
    self.scrollView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:self.scrollView];
    [self.scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_equalTo(0);
        
        make.height.mas_equalTo(44);
    }];

    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
