//
//  FenLeiViewController.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/13.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageView.h"
@interface FenLeiViewController : UIViewController

@end
@interface FenLei2Cell : UICollectionViewCell
@property(nonatomic,strong) TRImageView *iconView;
@property(nonatomic,strong) UILabel *nameLb;
@end