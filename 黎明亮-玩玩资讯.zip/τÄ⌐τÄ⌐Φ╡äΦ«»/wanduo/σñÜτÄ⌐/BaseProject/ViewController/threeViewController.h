//
//  threeViewController.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface threeViewController : UIViewController
-(id)initWithID:(NSNumber*)ID;
@end
