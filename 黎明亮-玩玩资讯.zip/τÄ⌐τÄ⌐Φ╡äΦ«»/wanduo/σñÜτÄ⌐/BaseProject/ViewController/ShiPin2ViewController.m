//
//  ShiPin2ViewController.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ShiPin2ViewController.h"
#import "ScrollDisplayViewController.h"
#import "ShiPinViewController.h"
#import "FenLeiViewController.h"
#define kWid kWindowW/3-30
@interface ShiPin2ViewController ()<ScrollDisplayViewControllerDelegate>
@property(nonatomic,strong)ScrollDisplayViewController*sdVC;
@property(nonatomic,strong)UIScrollView*scrollView;
@property(nonatomic,strong)NSMutableArray*btns;
@property(nonatomic,strong)UIView*lineView;
@property(nonatomic,strong)UIButton*currentBtn;
@end

@implementation ShiPin2ViewController
-(void)ScrollDisplayViewController:(ScrollDisplayViewController *)ScrollDisplayViewController currentIndex:(NSInteger)index{
    _currentBtn.selected=NO;
    _currentBtn=_btns[index];
    _currentBtn.selected=YES;
    [self.lineView mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.width.mas_equalTo(kWindowW/3);
        make.height.mas_equalTo(2);
        make.centerX.mas_equalTo(_currentBtn);
        make.top.mas_equalTo(_currentBtn.mas_bottom).mas_equalTo(8);
    }];
    
}

-(NSMutableArray*)btns{
    if (!_btns) {
        _btns=[NSMutableArray new];
    }
    return _btns;
}


-(UIView*)lineView{
    if (!_lineView) {
        _lineView=[UIView new];
        _lineView.backgroundColor=kRGBColor(56, 106, 198);
    }
    return _lineView;
}

-(UIScrollView*)scrollView{
    if (!_scrollView) {
        _scrollView=[UIScrollView new];
        NSArray*arr=@[@"分类导航",@"排行榜",@"最新视频"];
        UIView*lastView=nil;
        for(int i=0;i<arr.count;i++){
            UIButton*btn=[UIButton buttonWithType:0];
            [btn setTitle:arr[i] forState:0];
            [btn setTitleColor:kRGBColor(89, 89, 89) forState:UIControlStateNormal];
            [btn setTitleColor:self.lineView.backgroundColor forState:UIControlStateSelected];
            if (i==0) {
                _currentBtn=btn;
                btn.selected=YES;
            }
            [btn bk_addEventHandler:^(UIButton *sender) {
                if (_currentBtn!=sender) {
                    _currentBtn.selected=NO;
                    sender.selected=YES;
                    _currentBtn=sender;
                    [self.lineView mas_remakeConstraints:^(MASConstraintMaker *make) {
                        make.width.mas_equalTo(kWid);
                        make.height.mas_equalTo(2);
                        make.centerX.mas_equalTo(sender);
                        make.top.mas_equalTo(sender.mas_bottom).mas_equalTo(8);
                    }];
                    _sdVC.currentPage=[_btns indexOfObject:sender];
                }
            } forControlEvents:UIControlEventTouchUpInside];
            [_scrollView addSubview:btn];
            [btn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.size.mas_equalTo(CGSizeMake(kWid , 24));
                make.centerY.mas_equalTo(_scrollView);
                if (lastView) {
                    make.left.mas_equalTo(lastView.mas_right).mas_equalTo(10);
                    
                }else{
                    make.left.mas_equalTo(10);
                    
                }
                
                
            }];
            lastView=btn;
            [self.btns addObject:btn];
        }
        
        
        [lastView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(_scrollView.mas_right).mas_equalTo(-10);
        }];
        _scrollView.showsHorizontalScrollIndicator=NO;
        [_scrollView addSubview:self.lineView];
        [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.width.mas_equalTo(kWid);
            make.height.mas_equalTo(2);
            UIButton*btn=_btns[0];
            make.centerX.mas_equalTo(btn);
            make.top.mas_equalTo(btn.mas_bottom).mas_equalTo(8);
        }];
        
    }
    
    return _scrollView;
}

-(void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    self.scrollView.hidden=NO;
    
}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.scrollView.hidden=YES;
    
    
}



-(ShiPinViewController*)latestVCWithType:(ShiPinType)type{
    
    ShiPinViewController*vc=[kStoryboard(@"Main")instantiateViewControllerWithIdentifier:@"ShiPinViewController"];
    vc.type=type;
    return vc;
    
}

-(FenLeiViewController*)fenlei{
    FenLeiViewController*vc=[kStoryboard(@"Main")instantiateViewControllerWithIdentifier:@"FenLeiViewController"];
    return vc;

}
-(ScrollDisplayViewController*)sdVC{
    if (!_sdVC) {
        NSArray*vcs=@[[self fenlei],
                       [self latestVCWithType:ShiPinTypeTopN],
                      [self latestVCWithType:ShiPinTypeNewest],
                     
                      ];
        
        
        _sdVC=[[ScrollDisplayViewController alloc]initWithViewControllers:vcs];
        _sdVC.autoCycle=NO;
        _sdVC.showPathControl=NO;
        _sdVC.delegate=self;
    }
    
    return _sdVC;
    
    
}



- (void)viewDidLoad {
    [super viewDidLoad];
    [self addChildViewController:self.sdVC];
    [self.view addSubview:self.sdVC.view];
    [self.sdVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.left.right.mas_equalTo(0);
        make.top.mas_equalTo(44);
    }];
    self.scrollView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:self.scrollView];
    [self.scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.right.mas_equalTo(0);
        
        make.height.mas_equalTo(44);
    }];
   
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
