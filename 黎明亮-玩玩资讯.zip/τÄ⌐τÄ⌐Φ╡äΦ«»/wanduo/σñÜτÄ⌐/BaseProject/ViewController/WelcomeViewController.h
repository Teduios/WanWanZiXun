//
//  WelcomeViewController.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WelcomeViewController : UIViewController

@end
