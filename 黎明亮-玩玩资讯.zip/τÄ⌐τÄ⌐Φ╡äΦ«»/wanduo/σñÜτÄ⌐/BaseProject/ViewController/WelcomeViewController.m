//
//  WelcomeViewController.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/23.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "WelcomeViewController.h"

@interface WelcomeViewController ()<UIPageViewControllerDelegate, UIPageViewControllerDataSource>
//数组，存放用于展示在翻页控制器中的 视图控制
@property(nonatomic,strong) NSArray *controllers;
//创建翻页控制器
@property(nonatomic,strong) UIPageViewController *pageVC;
@end
@implementation WelcomeViewController
- (UIPageViewController *)pageVC{
    if (!_pageVC) {
        _pageVC=[[UIPageViewController alloc] initWithTransitionStyle:1 navigationOrientation:0 options:nil];
        _pageVC.delegate = self;
        _pageVC.dataSource = self;
        //设置当前显示哪个控制器
        [_pageVC setViewControllers:@[self.controllers.firstObject] direction:0 animated:YES completion:^(BOOL finished) {
            
        }];
    }
    return _pageVC;
}

- (NSArray *)controllers{
    if (!_controllers) {
        UIViewController *v1=[[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"welcome1"];
 UIViewController *v2=[[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateViewControllerWithIdentifier:@"welcome2"];
     
        _controllers=@[v1, v2, ];
    }
    return _controllers;
}
- (nullable UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController{
    NSInteger index=[self.controllers indexOfObject:viewController];
    if (index == 0) {
        return nil;
        //     这里返回nil， 则不会循环滚动
    }
    return self.controllers[index-1];
}
- (nullable UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController{
    NSInteger index=[self.controllers indexOfObject:viewController];
    if (index == self.controllers.count-1) {
        return nil;
    }
    return self.controllers[index+1];
}
- (void)pageViewController:(UIPageViewController *)pageViewController didFinishAnimating:(BOOL)finished previousViewControllers:(NSArray<UIViewController *> *)previousViewControllers transitionCompleted:(BOOL)completed{
    //这个协议方法 只有手动滑动时触发
    if (completed) {
        [self configPageControl];
    }
}
- (void)configPageControl{
    id currentVC = self.pageVC.viewControllers.firstObject;
    NSInteger index=[self.controllers indexOfObject:currentVC];
    UIPageControl *pageControl=(UIPageControl *)[self.view viewWithTag:1000];
    pageControl.currentPage = index;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //把控制器 加到一个控制器中, 主要作用是保存pageVC的指针，防止被释放
    [self addChildViewController:self.pageVC];
    //把pageVC的视图 添加到 当前控制器，显示出来
    [self.view addSubview:self.pageVC.view];
    [self.pageVC.view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.view);
    }];
    

 
    
    UIPageControl *pageControl=[UIPageControl new];
    pageControl.numberOfPages=self.controllers.count;
    [self.view addSubview:pageControl];
    //位置  距离屏幕下方60， 横向居中
    [pageControl mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.mas_equalTo(-60);
        make.centerX.mas_equalTo(self.view);
    }];
    pageControl.tag = 1000;
    
    //mas_makeConstraints 首次添加约束
    //mas_updateConstraints 用新的约束覆盖旧的
    //mas_remakeConstraints 删除之前约束，添加新约束
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */


@end
