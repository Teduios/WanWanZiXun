//
//  photoViewController.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/4.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "photoViewController.h"
#import "PSCollectionView.h"
#import "photoViewModel.h"
#import "PicViewController.h"
@interface photoViewController ()<UIScrollViewDelegate,PSCollectionViewDelegate, PSCollectionViewDataSource>
@property(nonatomic,strong)photoViewModel*photoVM;
@property(nonatomic,strong)PSCollectionView*collectionView;
@end

@implementation photoViewController

-(photoViewModel*)photoVM{

    if (!_photoVM) {
        _photoVM=[[photoViewModel alloc]initWithDuoWanType:_type];
    }
    return _photoVM;
}



- (void)viewDidLoad {
    [super viewDidLoad];
    self.collectionView = [[PSCollectionView alloc] initWithFrame:CGRectMake(0, 0, kWindowW, kWindowH)];
    self.collectionView.delegate = self;
    self.collectionView.collectionViewDelegate = self;
    self.collectionView.collectionViewDataSource = self;
    [self.view addSubview:self.collectionView];
    //设置竖向 两行
    self.collectionView.numColsPortrait = 2;
    //头部刷新
    self.collectionView.header =[MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.photoVM refreshDataCompletionHandle:^(NSError *error) {
            //AF的回调 是在主线程中
            [self.collectionView reloadData];
            if (error) {
                [self showErrorMsg:error.description];
            }
            [self.collectionView.header endRefreshing];
        }];
    }];
    [self.collectionView.header beginRefreshing];
    
    self.collectionView.footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self.photoVM getMoreDataCompletionHandle:^(NSError *error) {
            [self.collectionView reloadData];
            if (error) {
                [self showErrorMsg:error.description];
            }
            [self.collectionView.footer endRefreshing];
        }];
    }];

}

-(NSInteger)numberOfRowsInCollectionView:(PSCollectionView *)collectionView{
    return self.photoVM.rowNumber;

}

-(CGFloat)collectionView:(PSCollectionView *)collectionView heightForRowAtIndex:(NSInteger)index{

    AlbumDataModel *data = [self.photoVM.dataArr objectAtIndex:index];
    CGFloat width =data.coverWidth.floatValue;
    CGFloat height = data.coverHeight.floatValue;
    return (kWindowW/2 -12) *height/width;

}

-(PSCollectionViewCell*)collectionView:(PSCollectionView *)collectionView cellForRowAtIndex:(NSInteger)index{

    PSCollectionViewCell *cell = [collectionView dequeueReusableViewForClass:[PSCollectionViewCell class]];
    if (!cell) {
        cell = [[PSCollectionViewCell alloc] initWithFrame:CGRectZero];
        UIImageView *imageView=[UIImageView new];
        [cell addSubview:imageView];
        imageView.tag = 100;
    }
    UIImageView *iv = (UIImageView *)[cell viewWithTag:100];
    iv.frame = CGRectMake(0, 0, kWindowW/2 -12, [self collectionView:collectionView heightForRowAtIndex:index]);
    [iv setImageWithURL:[self.photoVM iconForRow:index]];
    return cell;


}
-(void)collectionView:(PSCollectionView *)collectionView didSelectCell:(PSCollectionViewCell *)cell atIndex:(NSInteger)index{
    PicViewController*vc=[[PicViewController alloc]initWithgalleryId:[self.photoVM galleryIdForRow:index]];
    [self.navigationController pushViewController:vc animated:YES];
    
    self.tabBarController.tabBar.hidden=YES;
    
    
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = NO;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
