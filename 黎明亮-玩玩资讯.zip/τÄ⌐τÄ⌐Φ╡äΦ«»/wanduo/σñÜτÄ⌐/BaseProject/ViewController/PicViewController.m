//
//  Skin3DJHViewController.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/18.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "PicViewController.h"
#import "iCarousel.h"
#import "PicViewModel.h"
#import "TRImageView.h"


@interface PicViewController ()<iCarouselDelegate,iCarouselDataSource>
@property(nonatomic,strong)PicViewModel *picsVM;
@property(nonatomic,strong)iCarousel *ic;
@end

@implementation PicViewController
-(id)initWithgalleryId:(NSString *)galleryId{

    if (self=[super init]) {
        self.galleryId =galleryId;
    }
    return self;
}
- (id)init{
    if (self = [super init]) {
        NSAssert1(NO, @"%s 必须使用initWithAid方法初始化", __func__);
    }
    return self;
}

- (PicViewModel *)picsVM
{
    if (!_picsVM) {
        _picsVM = [[PicViewModel alloc]initWithgalleryId:_galleryId];
    }
    return _picsVM;
}

-(iCarousel *)ic
{
    if (!_ic) {
        _ic = [[iCarousel alloc]init];
        _ic.delegate = self;
        _ic.dataSource = self;
        _ic.type = 0;
        // 翻页模式
        _ic.pagingEnabled = YES;
        // 改变为竖向展示
    }
    return _ic;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    // 将图片显示到界面上
    self.ic.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.ic];
    
    [self.ic mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(0);
    }];
    
    [self.picsVM getDataFromNetCompleteHandle:^(NSError *error) {
        [self.ic reloadData];
    }];
    
    

}


#pragma mark ----iCarouselDelegate,iCarouselDataSource

- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    return self.picsVM.rowNumber;
}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view
{
   
    
    if (!view) {
        NSInteger width = kWindowW;
        NSInteger height = kWindowH-20;
        view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, width, height)];
        UILabel*label=[UILabel new];
        label.tag=200;
        label.backgroundColor=[UIColor whiteColor];
        TRImageView *imageView = [TRImageView new];
        imageView.tag = 100;
        [view addSubview:label];
        [view addSubview:imageView];
        imageView.contentMode = UIViewContentModeScaleAspectFill;
        [label mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.mas_equalTo(0);
            make.left.right.mas_equalTo(0);
            make.height.mas_equalTo(50);
        }];
        [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.mas_equalTo(0);
            make.bottom.mas_equalTo(-50);
        }];
    }
    TRImageView *imageView = (TRImageView *)[view viewWithTag:100];
    UILabel*label=(UILabel*)[view viewWithTag:200];
    [imageView.imageView setImageWithURL:[self.picsVM picURLForRow:index]];
    label.text=[self.picsVM picDescForRow:index];
    return view;
    
}




- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index
{
    NSLog(@"点击了第%ld", (long)index);
}






/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
