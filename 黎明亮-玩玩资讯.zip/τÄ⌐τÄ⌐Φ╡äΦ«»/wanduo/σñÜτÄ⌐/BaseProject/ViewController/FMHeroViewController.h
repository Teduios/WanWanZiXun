//
//  FMHeroViewController.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/16.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageView.h"
@interface FMHeroViewController : UIViewController

@end
@interface FMHeroCell : UICollectionViewCell
@property(nonatomic,strong) TRImageView *enNameView;
@property(nonatomic,strong) UILabel *titleLb;
@property(nonatomic,strong) UILabel *cnNameLb;
@property(nonatomic,strong) UILabel *locationLb;
@end
