//
//  ShiPinViewController.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ShiPinViewModel.h"
@interface ShiPinViewController : UIViewController
@property(nonatomic)ShiPinType type;
@end
