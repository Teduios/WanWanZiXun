
//
//  ShiPinViewController.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/7.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ShiPinViewController.h"

#import "ShiPinViewModel.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
#import "ShiPinNetManager.h"
@interface ShiPinViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic,strong)ShiPinViewModel*shipinVM;

@end

@implementation ShiPinViewController

-(ShiPinViewModel*)shipinVM{
    if (!_shipinVM) {
        _shipinVM=[[ShiPinViewModel alloc]initWithShiPinType:_type];
    }
    return _shipinVM;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _tableView.header=[MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self.shipinVM refreshDataCompletionHandle:^(NSError *error) {
            [_tableView.header endRefreshing];
            [_tableView reloadData];
        }];
    }];
    [self.tableView.header beginRefreshing];
    _tableView.footer=[MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [self.shipinVM getMoreDataCompletionHandle:^(NSError *error) {
            if (error) {
                [self showErrorMsg:error.description];
            }
            [_tableView.footer endRefreshing];
            [self.tableView reloadData];
        }];
    }];
    
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.shipinVM.rowNumber;
    
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"Cell"];
    UIImageView*imageView=(UIImageView*)[cell.contentView viewWithTag:100];
    UILabel*titlelabel=(UILabel*)[cell.contentView viewWithTag:200];
    UILabel*readplay=(UILabel*)[cell.contentView viewWithTag:300];
    UILabel*videolength=(UILabel*)[cell.contentView viewWithTag:400];
    [imageView setImageWithURL:[self.shipinVM iconForRow:indexPath.row]];
    titlelabel.text=[self.shipinVM titleForRow:indexPath.row];
    readplay.text=[self.shipinVM upTimeForRow:indexPath.row];
    videolength.text=[self.shipinVM videoLengthForRow:indexPath.row];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [[AVAudioSession sharedInstance]setCategory:AVAudioSessionCategoryPlayback error:nil];
    [[AVAudioSession sharedInstance]setActive:YES error:nil];
    AVPlayerViewController*vc=[AVPlayerViewController new];
    
    [ShiPinNetManager getVID:[NSString stringWithFormat:@"%@",[self.shipinVM VidForRow:indexPath.row] ]completionHandle:^(BoFangModel *model, NSError *error) {
        AVPlayer*play=[AVPlayer playerWithURL:[NSURL URLWithString: [model.result.items.YiQian.transcode.urls firstObject]]];
        vc.player=play;
        [self presentViewController:vc animated:YES  completion:nil];
        [vc.player play];
        
    }];
    
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
