//
//  MissViewController.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "MissViewController.h"
#import "ShiPinViewCell.h"
#import "MissViewModel.h"
#import "TRImageView.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
#import "ShiPinNetManager.h"
@interface MissViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)MissViewModel*missVM;
@property(nonatomic,strong)TRImageView*iconView;
@property(nonatomic,strong)UITableView*tableView;
@end

@implementation MissViewController

-(MissViewModel*)missVM{

    if (!_missVM) {
        _missVM=[[MissViewModel alloc]initWithName:@"missjs"];
    }
    return _missVM;
}
- (UITableView *)tableView {
    if(_tableView == nil) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        [_tableView registerClass:[ShiPinViewCell class] forCellReuseIdentifier:@"Cell"];
        _tableView.tableFooterView = [UIView new];
        _tableView.rowHeight = 80;
        [self.view addSubview:_tableView];
        [_tableView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(0);
        }];
        self.tableView.header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
            [self.missVM refreshDataCompletionHandle:^(NSError *error) {

                [self.tableView.header endRefreshing];
                [self.tableView reloadData];
            }];
        }];
        self.tableView.footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
            [self.missVM getMoreDataCompletionHandle:^(NSError *error) {

                [self.tableView.footer endRefreshing];
                [self.tableView reloadData];
            }];
        }];

            
    }
    return _tableView;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.missVM.rowNumber;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    ShiPinViewCell*cell=[tableView dequeueReusableCellWithIdentifier:@"Cell"];
    [cell.iconIV.imageView setImageWithURL:[self.missVM iconForRow:indexPath.row]];
    cell.titleLb.text=[self.missVM titleForRow:indexPath.row];
    cell.timeLb.text=[self.missVM upTimeForRow:indexPath.row];
    cell.videoLenghtLb.text=[self.missVM videoLengthForRow:indexPath.row];
    return cell;

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [[AVAudioSession sharedInstance]setCategory:AVAudioSessionCategoryPlayback error:nil];
    [[AVAudioSession sharedInstance]setActive:YES error:nil];
    AVPlayerViewController*vc=[AVPlayerViewController new];
    
    [ShiPinNetManager getVID:[NSString stringWithFormat:@"%@",[self.missVM VidForRow:indexPath.row] ]completionHandle:^(BoFangModel *model, NSError *error) {
        AVPlayer*play=[AVPlayer playerWithURL:[NSURL URLWithString: [model.result.items.YiQian.transcode.urls firstObject]]];
        vc.player=play;
        [self presentViewController:vc animated:YES  completion:nil];
        [vc.player play];
        
    }];
    
    
    
    
}


- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView.header beginRefreshing];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
