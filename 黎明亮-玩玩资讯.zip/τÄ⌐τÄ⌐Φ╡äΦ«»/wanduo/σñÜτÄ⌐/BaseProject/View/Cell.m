//
//  Cell.m
//  Demo03_自定义项和布局
//
//  Created by xiaoz on 15/9/16.
//  Copyright (c) 2015年 xiaoz. All rights reserved.
//

#import "Cell.h"

@implementation Cell

//没有xib文件时，系统创建Cell实例时，调用此方法
//frame中会有这个cell的位置 和 大小
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        //创建label
        UILabel *label = [[UILabel alloc]init];
        label.frame = CGRectMake(0, 0, frame.size.width, frame.size.height);
        label.textAlignment = NSTextAlignmentCenter;
        label.font = [UIFont boldSystemFontOfSize:30];
        self.label = label;
        [self.contentView addSubview:label];
        
        //设置bgImageView
        self.bgImageView = [[UIImageView alloc]init];
        self.backgroundView = self.bgImageView;
    }
    return self;
}



@end



