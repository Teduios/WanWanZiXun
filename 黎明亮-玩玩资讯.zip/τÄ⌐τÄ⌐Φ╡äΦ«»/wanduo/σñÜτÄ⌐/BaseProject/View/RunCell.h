//
//  RunCell.h
//  BaseProject
//
//  Created by apple－jd08 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RunCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *iconV;
@property (weak, nonatomic) IBOutlet UILabel *nameLb;
@property (weak, nonatomic) IBOutlet UILabel *rowLb;
@property (weak, nonatomic) IBOutlet UILabel *iplevLb;
@property (weak, nonatomic) IBOutlet UILabel *levLb;
@property (weak, nonatomic) IBOutlet UILabel *propLb;

@end
