//
//  Cell.h
//  Demo03_自定义项和布局
//
//  Created by xiaoz on 15/9/16.
//  Copyright (c) 2015年 xiaoz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Cell : UICollectionViewCell

@property(nonatomic,strong)UILabel *label;
@property(nonatomic,strong)UIImageView *bgImageView;



@end







