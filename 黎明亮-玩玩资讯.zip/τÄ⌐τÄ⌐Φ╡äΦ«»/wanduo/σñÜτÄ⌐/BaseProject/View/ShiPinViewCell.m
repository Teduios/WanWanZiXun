//
//  ShiPinViewCell.m
//  BaseProject
//
//  Created by apple－jd08 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "ShiPinViewCell.h"

@implementation ShiPinViewCell
-(TRImageView*)iconIV{
    if (!_iconIV) {
        _iconIV=[TRImageView new];
        [self.contentView addSubview:_iconIV];
        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(7);
            make.size.mas_equalTo(CGSizeMake(92, 70));
            make.centerY.mas_equalTo(0);
        }];
    }
    return _iconIV;
}
-(UILabel*)titleLb{
    if (!_titleLb) {
        _titleLb=[UILabel new];
        _titleLb.numberOfLines=0;
        _titleLb.font=[UIFont systemFontOfSize:15];
        [self.contentView addSubview:_titleLb];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(_iconIV.mas_right).mas_equalTo(8);
            make.right.mas_equalTo(-10);
            make.topMargin.mas_equalTo(_iconIV.mas_topMargin).mas_equalTo(3);

        }];
        
    }
    return _titleLb;
}

-(UILabel*)timeLb{
    if (!_timeLb) {
        _timeLb=[UILabel new];

        _timeLb.font=[UIFont systemFontOfSize:13];
        [self.contentView addSubview:_timeLb];
        [_timeLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.mas_equalTo(_iconIV.mas_bottom);
            make.left.mas_equalTo(_iconIV.mas_right).mas_equalTo(8);
            
        }];
    }

    return _timeLb;
}
-(UILabel*)videoLenghtLb{
    if (!_videoLenghtLb) {
        _videoLenghtLb=[UILabel new];
        [self.contentView addSubview:_videoLenghtLb];
        [_videoLenghtLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottomMargin.mas_equalTo(_iconIV.mas_bottomMargin);
            make.rightMargin.mas_equalTo(_titleLb.mas_rightMargin);
        }];
    }
    return _videoLenghtLb;
}

-(id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
    }
    return self;
}




- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
