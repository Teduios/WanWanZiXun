//
//  Myflow.m
//  lmll
//
//  Created by apple－jd08 on 15/9/16.
//  Copyright (c) 2015年 apple－jd08. All rights reserved.
//

#import "Myflow.h"

@implementation Myflow
-(instancetype)init{
    self=[super init];
    if (self) {
        self.itemSize=CGSizeMake(300, 300);
        self.minimumLineSpacing=50;

        self.sectionInset=UIEdgeInsetsMake(87, 0, 88, 0);
        self.scrollDirection=UICollectionViewScrollDirectionHorizontal;
    }
    return self;

}
-(BOOL)shouldInvalidateLayoutForBoundsChange:(CGRect)newBounds{

    return YES;
}

-(NSArray*)layoutAttributesForElementsInRect:(CGRect)rect{

    NSArray*array=[super layoutAttributesForElementsInRect:rect];
    CGRect visiable=CGRectZero;
    visiable.size=self.collectionView.frame.size;
    visiable.origin=self.collectionView.contentOffset;
    CGFloat blackX=CGRectGetMidX(visiable);
    for(UICollectionViewLayoutAttributes *arr in array){
    
        CGFloat redX=arr.center.x;
        CGFloat distance=blackX-redX;
        CGFloat scale=distance/200;
        if (ABS(distance)<=200) {
            
            CGFloat zoom=1+0.5*(1-ABS(scale));
            arr.transform3D=CATransform3DMakeScale(zoom, zoom, 1);
            
        }
    }
    return array;

    
}


-(CGPoint)targetContentOffsetForProposedContentOffset:(CGPoint)proposedContentOffset withScrollingVelocity:(CGPoint)velocity{

    CGFloat blackCenter=proposedContentOffset.x+self.collectionView.bounds.size.width/2;
    CGRect blackRect=CGRectMake(proposedContentOffset.x, 0, self.collectionView.bounds.size.width, self.collectionView.bounds.size.height);
    NSArray*array=[super layoutAttributesForElementsInRect:blackRect];
    CGFloat offSetX=MAXFLOAT;
    for(UICollectionViewLayoutAttributes *attr in array){
        CGFloat redCenter=attr.center.x;
        CGFloat distance=redCenter- blackCenter;
        if (ABS(distance)<ABS(offSetX)) {
            offSetX=distance;
        }
        
    }
    
    return CGPointMake(proposedContentOffset.x+offSetX, proposedContentOffset.y);





}














@end
