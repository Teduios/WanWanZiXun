//
//  RunCell.m
//  BaseProject
//
//  Created by apple－jd08 on 15/12/3.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "RunCell.h"

@implementation RunCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
