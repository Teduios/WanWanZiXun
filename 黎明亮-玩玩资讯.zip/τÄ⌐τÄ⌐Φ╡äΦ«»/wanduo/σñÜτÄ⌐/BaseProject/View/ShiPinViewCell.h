//
//  ShiPinViewCell.h
//  BaseProject
//
//  Created by apple－jd08 on 15/11/12.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRImageView.h"
@interface ShiPinViewCell : UITableViewCell

@property(nonatomic,strong)TRImageView *iconIV;
//* 题目标签 */
@property(nonatomic,strong)UILabel *titleLb;
//* 长题目标签 */
@property(nonatomic,strong)UILabel *timeLb;
//* 点击数标签 */
//* laben for clicks number */
@property(nonatomic,strong)UILabel *videoLenghtLb;

@end
