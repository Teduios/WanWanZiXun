//
//  AppDelegate.m
//  BaseProject
//
//  Created by jiyingxin on 15/10/21.
//  Copyright © 2015年 Tarena. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+Category.h"
#import "WelcomeViewController.h"
#import "UMSocial.h"
#import "UMSocialWechatHandler.h"
#import "UMSocialQQHandler.h"
#define AppKey @"564ea844e0f55acda0000d1d"
@interface AppDelegate ()
@property(nonatomic,strong)NSArray*abc;
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    [self initializeWithApplication:application];

    [UMSocialData setAppKey:AppKey];
    [UMSocialQQHandler setQQWithAppId:@"1104539912" appKey:@"eFVgRits2fqf36Jf" url:@"http://www.umeng.com/social"];
  

    
    
    
    
    
    
    
    
    
      NSDictionary *infoDic=[[NSBundle mainBundle] infoDictionary];
    NSString *key =@"CFBundleShortVersionString";
    NSString *currentVersion=infoDic[key];
    //已运行过的版本号需要持久化处理，通常存储在userDefault中
    NSString *runVersion=[[NSUserDefaults standardUserDefaults] stringForKey:key];
    if (runVersion==nil || ![runVersion isEqualToString:currentVersion] ) {
        //没运行过 或者 版本号不一致，则显示欢迎页
        self.window = [[UIWindow alloc]initWithFrame:[[UIScreen mainScreen]bounds]];
        WelcomeViewController *vc = [WelcomeViewController new];
        self.window.rootViewController = vc;
        [self.window makeKeyAndVisible];

        //保存新的版本号,防止下次运行再显示欢迎页
        [[NSUserDefaults standardUserDefaults] setValue:currentVersion forKey:key];
    }else{
        self.window = [[UIWindow alloc]initWithFrame:[[UIScreen mainScreen]bounds]];
        self.window.rootViewController = kVCFromSb(@"mainViewController", @"Main");
        [self.window makeKeyAndVisible];

    }

 

    
    return YES;
}


@end
